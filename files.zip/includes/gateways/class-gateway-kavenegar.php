<?php
/**
 * Kavenegar Gateway Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Gateway_Kavenegar extends Labasino_SMS_Gateway_Abstract {
    
    /**
     * API endpoint
     */
    private $api_url = 'https://api.kavenegar.com/v1/';
    
    /**
     * Initialize gateway
     */
    protected function init() {
        $this->id = 'kavenegar';
        $this->name = 'کاوه نگار (Kavenegar)';
    }
    
    /**
     * Send SMS
     */
    public function send($mobile, $message) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $api_key = $this->get_setting('api_key');
        $sender = $this->get_setting('sender');
        
        if (empty($api_key)) {
            return array(
                'success' => false,
                'message' => 'API Key تنظیم نشده است'
            );
        }
        
        $url = $this->api_url . $api_key . '/sms/send.json';
        
        $args = array(
            'method' => 'POST',
            'body' => array(
                'sender' => $sender,
                'receptor' => $mobile,
                'message' => $message
            )
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, $message, 'general', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['return']['status']) && $body['return']['status'] == 200) {
            $this->log($mobile, $message, 'general', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'پیامک با موفقیت ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['return']['message']) ? $body['return']['message'] : 'خطای ناشناخته';
            $this->log($mobile, $message, 'general', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
    
    /**
     * Send OTP using Lookup (Template)
     */
    public function send_otp($mobile, $code) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $api_key = $this->get_setting('api_key');
        $template = $this->get_setting('otp_template', 'verify');
        
        if (empty($api_key)) {
            return array(
                'success' => false,
                'message' => 'API Key تنظیم نشده است'
            );
        }
        
        // Use Lookup API for OTP
        $url = $this->api_url . $api_key . '/verify/lookup.json';
        
        $args = array(
            'method' => 'POST',
            'body' => array(
                'receptor' => $mobile,
                'token' => $code,
                'template' => $template
            )
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['return']['status']) && $body['return']['status'] == 200) {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'کد تایید ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['return']['message']) ? $body['return']['message'] : 'خطای ناشناخته';
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
}
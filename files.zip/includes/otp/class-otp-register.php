<?php
/**
 * OTP Register Class
 * Handles registration with OTP
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_OTP_Register {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // AJAX handlers
        add_action('wp_ajax_nopriv_labasino_send_register_otp', array($this, 'ajax_send_otp'));
        add_action('wp_ajax_nopriv_labasino_verify_register_otp', array($this, 'ajax_verify_otp'));
        
        // Make mobile required in checkout
        add_filter('woocommerce_billing_fields', array($this, 'make_mobile_required'));
    }
    
    /**
     * AJAX: Send registration OTP
     */
    public function ajax_send_otp() {
        check_ajax_referer('labasino-sms-frontend', 'nonce');
        
        $mobile = isset($_POST['mobile']) ? sanitize_text_field($_POST['mobile']) : '';
        
        if (empty($mobile)) {
            wp_send_json_error(array(
                'message' => 'لطفاً شماره موبایل را وارد کنید'
            ));
        }
        
        // Check if mobile already exists
        $user = $this->get_user_by_mobile($mobile);
        
        if ($user) {
            wp_send_json_error(array(
                'message' => 'این شماره موبایل قبلاً ثبت شده است. لطفاً وارد شوید.'
            ));
        }
        
        // Send OTP
        $otp_manager = Labasino_SMS_OTP_Manager::get_instance();
        $result = $otp_manager->create_and_send_otp($mobile);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'message' => $result['message'],
                'expires_in' => $result['expires_in']
            ));
        } else {
            wp_send_json_error(array(
                'message' => $result['message']
            ));
        }
    }
    
    /**
     * AJAX: Verify registration OTP and create account
     */
    public function ajax_verify_otp() {
        check_ajax_referer('labasino-sms-frontend', 'nonce');
        
        $mobile = isset($_POST['mobile']) ? sanitize_text_field($_POST['mobile']) : '';
        $code = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';
        $first_name = isset($_POST['first_name']) ? sanitize_text_field($_POST['first_name']) : '';
        $last_name = isset($_POST['last_name']) ? sanitize_text_field($_POST['last_name']) : '';
        
        if (empty($mobile) || empty($code)) {
            wp_send_json_error(array(
                'message' => 'لطفاً تمام فیلدهای الزامی را پر کنید'
            ));
        }
        
        // Verify OTP
        $otp_manager = Labasino_SMS_OTP_Manager::get_instance();
        $result = $otp_manager->verify_otp($mobile, $code);
        
        if (!$result['success']) {
            wp_send_json_error(array(
                'message' => $result['message']
            ));
        }
        
        // Check if user already exists
        $existing_user = $this->get_user_by_mobile($mobile);
        if ($existing_user) {
            wp_send_json_error(array(
                'message' => 'این شماره موبایل قبلاً ثبت شده است'
            ));
        }
        
        // Create user
        $username = $this->generate_username($mobile);
        
        $user_data = array(
            'user_login' => $username,
            'user_pass' => wp_generate_password(20, true, true),
            'user_email' => $this->generate_email($mobile),
            'first_name' => $first_name,
            'last_name' => $last_name,
            'role' => 'customer'
        );
        
        $user_id = wp_insert_user($user_data);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(array(
                'message' => 'خطا در ایجاد حساب کاربری: ' . $user_id->get_error_message()
            ));
        }
        
        // Save mobile as billing phone
        update_user_meta($user_id, 'billing_phone', $mobile);
        update_user_meta($user_id, 'billing_first_name', $first_name);
        update_user_meta($user_id, 'billing_last_name', $last_name);
        
        // Mark as OTP-only user (no password required)
        update_user_meta($user_id, 'labasino_otp_only', 'yes');
        update_user_meta($user_id, 'labasino_mobile_verified', 'yes');
        update_user_meta($user_id, 'labasino_registration_date', current_time('mysql'));
        
        // Log user in
        wp_clear_auth_cookie();
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, true);
        
        Labasino_SMS_Logger::success('New user registered via OTP', array(
            'user_id' => $user_id,
            'mobile' => $mobile
        ));
        
        do_action('labasino_sms_after_otp_register', $user_id, $mobile);
        
        // Send welcome SMS
        $this->send_welcome_sms($mobile, $first_name);
        
        // Get redirect URL
        $redirect_to = isset($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : wc_get_page_permalink('myaccount');
        
        wp_send_json_success(array(
            'message' => 'ثبت‌نام با موفقیت انجام شد',
            'redirect_to' => $redirect_to,
            'user' => array(
                'id' => $user_id,
                'display_name' => $first_name . ' ' . $last_name
            )
        ));
    }
    
    /**
     * Generate unique username from mobile
     */
    private function generate_username($mobile) {
        $base_username = 'user_' . substr($mobile, -8);
        $username = $base_username;
        $counter = 1;
        
        while (username_exists($username)) {
            $username = $base_username . '_' . $counter;
            $counter++;
        }
        
        return $username;
    }
    
    /**
     * Generate email from mobile
     */
    private function generate_email($mobile) {
        $domain = parse_url(home_url(), PHP_URL_HOST);
        return 'user_' . substr($mobile, -10) . '@' . $domain;
    }
    
    /**
     * Get user by mobile number
     */
    private function get_user_by_mobile($mobile) {
        $users = get_users(array(
            'meta_key' => 'billing_phone',
            'meta_value' => $mobile,
            'number' => 1
        ));
        
        return !empty($users) ? $users[0] : null;
    }
    
    /**
     * Send welcome SMS
     */
    private function send_welcome_sms($mobile, $name) {
        $send_welcome = get_option('labasino_sms_send_welcome', 'yes');
        
        if ($send_welcome !== 'yes') {
            return;
        }
        
        $template = get_option('labasino_sms_welcome_template', 
            'سلام {name}، به {shop_name} خوش آمدید!'
        );
        
        $message = str_replace(
            array('{name}', '{shop_name}'),
            array($name, get_bloginfo('name')),
            $template
        );
        
        $gateway = Labasino_SMS_Gateway_Manager::get_instance();
        $gateway->send($mobile, $message);
    }
    
    /**
     * Make billing phone required
     */
    public function make_mobile_required($fields) {
        if (isset($fields['billing_phone'])) {
            $fields['billing_phone']['required'] = true;
            $fields['billing_phone']['priority'] = 25;
            $fields['billing_phone']['label'] = 'شماره موبایل';
            $fields['billing_phone']['placeholder'] = '09xxxxxxxxx';
        }
        
        return $fields;
    }
}
<?php
/**
 * Abstract Gateway Class
 * Base class for all SMS gateways
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

abstract class Labasino_SMS_Gateway_Abstract {
    
    /**
     * Gateway ID
     */
    protected $id;
    
    /**
     * Gateway Name
     */
    protected $name;
    
    /**
     * Gateway settings
     */
    protected $settings = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->init();
        $this->load_settings();
    }
    
    /**
     * Initialize gateway
     */
    abstract protected function init();
    
    /**
     * Send SMS
     * 
     * @param string $mobile Mobile number
     * @param string $message Message content
     * @return array Response array with 'success' and 'message' keys
     */
    abstract public function send($mobile, $message);
    
    /**
     * Send OTP
     * 
     * @param string $mobile Mobile number
     * @param string $code OTP code
     * @return array Response array
     */
    abstract public function send_otp($mobile, $code);
    
    /**
     * Get gateway ID
     */
    public function get_id() {
        return $this->id;
    }
    
    /**
     * Get gateway name
     */
    public function get_name() {
        return $this->name;
    }
    
    /**
     * Load settings from database
     */
    protected function load_settings() {
        $this->settings = get_option('labasino_sms_gateway_' . $this->id, array());
    }
    
    /**
     * Get setting value
     * 
     * @param string $key Setting key
     * @param mixed $default Default value
     * @return mixed
     */
    protected function get_setting($key, $default = '') {
        return isset($this->settings[$key]) ? $this->settings[$key] : $default;
    }
    
    /**
     * Validate mobile number
     * 
     * @param string $mobile Mobile number
     * @return string|false Validated mobile or false
     */
    protected function validate_mobile($mobile) {
        // Remove spaces and special characters
        $mobile = preg_replace('/[^0-9+]/', '', $mobile);
        
        // Iranian mobile format
        if (preg_match('/^(\+98|0098|98|0)9\d{9}$/', $mobile)) {
            // Normalize to 09XXXXXXXXX format
            $mobile = preg_replace('/^(\+98|0098|98)/', '0', $mobile);
            return $mobile;
        }
        
        return false;
    }
    
    /**
     * Log SMS
     * 
     * @param string $mobile Mobile number
     * @param string $message Message
     * @param string $type Type (otp, order, general, etc.)
     * @param string $status Status (pending, sent, failed)
     * @param mixed $response Gateway response
     * @param int $user_id User ID (optional)
     * @param int $order_id Order ID (optional)
     */
    protected function log($mobile, $message, $type = 'general', $status = 'pending', $response = null, $user_id = null, $order_id = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'labasino_sms_log';
        
        $wpdb->insert(
            $table,
            array(
                'mobile' => $mobile,
                'message' => $message,
                'gateway' => $this->id,
                'type' => $type,
                'status' => $status,
                'response' => is_array($response) ? json_encode($response) : $response,
                'user_id' => $user_id,
                'order_id' => $order_id,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s')
        );
    }
    
    /**
     * Check if mobile is blacklisted
     * 
     * @param string $mobile Mobile number
     * @return bool
     */
    protected function is_blacklisted($mobile) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'labasino_sms_blacklist';
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE mobile = %s",
            $mobile
        ));
        
        return $count > 0;
    }
    
    /**
     * Make HTTP request
     * 
     * @param string $url URL
     * @param array $args Request arguments
     * @return array|WP_Error
     */
    protected function http_request($url, $args = array()) {
        $defaults = array(
            'timeout' => 30,
            'sslverify' => false,
        );
        
        $args = wp_parse_args($args, $defaults);
        
        return wp_remote_request($url, $args);
    }
}
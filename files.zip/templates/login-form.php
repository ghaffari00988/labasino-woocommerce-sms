<?php
/**
 * Login Form Template
 * Digikala-style login form
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

$redirect_to = isset($_GET['redirect_to']) ? esc_url($_GET['redirect_to']) : wc_get_page_permalink('myaccount');
?>

<div class="labasino-login-container">
    <div class="labasino-login-box">
        <div class="labasino-login-header">
            <h2>ورود | ثبت‌نام</h2>
            <p>سلام! لطفاً شماره موبایل خود را وارد کنید</p>
        </div>
        
        <!-- Step 1: Enter Mobile -->
        <div class="labasino-login-step" id="step-mobile">
            <form id="labasino-mobile-form">
                <div class="form-group">
                    <label for="labasino-mobile">شماره موبایل</label>
                    <input type="text" 
                           id="labasino-mobile" 
                           name="mobile" 
                           class="labasino-input" 
                           placeholder="09123456789"
                           inputmode="numeric"
                           pattern="[0-9]*"
                           maxlength="11"
                           required 
                           autocomplete="tel" />
                    <span class="input-icon">📱</span>
                </div>
                
                <button type="submit" class="labasino-btn labasino-btn-primary" id="send-otp-btn">
                    <span class="btn-text">ورود</span>
                    <span class="btn-loading" style="display: none;">
                        <span class="spinner"></span> در حال ارسال...
                    </span>
                </button>
                
                <div class="labasino-notice" id="mobile-notice" style="display: none;"></div>
            </form>
        </div>
        
        <!-- Step 2: Enter OTP -->
        <div class="labasino-login-step" id="step-otp" style="display: none;">
            <div class="step-header">
                <button type="button" class="back-btn" id="back-to-mobile">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
                <p>کد تایید را وارد کنید</p>
            </div>
            
            <p class="otp-info">
                کد تایید به شماره <strong id="display-mobile"></strong> ارسال شد
                <button type="button" class="edit-mobile-btn" id="edit-mobile">ویرایش</button>
            </p>
            
            <form id="labasino-otp-form">
                <div class="otp-inputs">
                    <input type="text" class="otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
                    <input type="text" class="otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
                    <input type="text" class="otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
                    <input type="text" class="otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
                    <input type="text" class="otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
                    <input type="text" class="otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
                </div>
                
                <div class="otp-timer">
                    <span id="otp-timer-text">ارسال مجدد کد تا <strong id="timer-count">120</strong> ثانیه</span>
                    <button type="button" class="resend-btn" id="resend-otp" style="display: none;">
                        ارسال مجدد کد
                    </button>
                </div>
                
                <button type="submit" class="labasino-btn labasino-btn-primary" id="verify-otp-btn">
                    <span class="btn-text">تایید و ادامه</span>
                    <span class="btn-loading" style="display: none;">
                        <span class="spinner"></span> در حال بررسی...
                    </span>
                </button>
                
                <div class="labasino-notice" id="otp-notice" style="display: none;"></div>
            </form>
        </div>
        
        <!-- Step 3: Register (if new user) -->
        <div class="labasino-login-step" id="step-register" style="display: none;">
            <div class="step-header">
                <h3>تکمیل ثبت‌نام</h3>
                <p>لطفاً اطلاعات خود را تکمیل کنید</p>
            </div>
            
            <form id="labasino-register-form">
                <div class="form-group">
                    <label for="first-name">نام <span class="required">*</span></label>
                    <input type="text" id="first-name" name="first_name" class="labasino-input" required />
                </div>
                
                <div class="form-group">
                    <label for="last-name">نام خانوادگی <span class="required">*</span></label>
                    <input type="text" id="last-name" name="last_name" class="labasino-input" required />
                </div>
                
                <button type="submit" class="labasino-btn labasino-btn-primary" id="register-btn">
                    <span class="btn-text">ثبت‌نام</span>
                    <span class="btn-loading" style="display: none;">
                        <span class="spinner"></span> در حال ثبت...
                    </span>
                </button>
                
                <div class="labasino-notice" id="register-notice" style="display: none;"></div>
            </form>
        </div>
        
        <input type="hidden" id="redirect-to" value="<?php echo esc_url($redirect_to); ?>" />
    </div>
    
    <div class="labasino-login-footer">
        <p>با ورود و ثبت‌نام، <a href="#">شرایط و قوانین</a> استفاده از خدمات را می‌پذیرم.</p>
    </div>
</div>
<?php
/**
 * Admin Settings Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Admin_Settings {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_menu', array($this, 'add_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_labasino_test_sms', array($this, 'ajax_test_sms'));
    }
    
    /**
     * Add admin menu
     */
    public function add_menu() {
        add_menu_page(
            'Labasino SMS',
            'Labasino SMS',
            'manage_options',
            'labasino-sms',
            array($this, 'render_dashboard_page'),
            'dashicons-email-alt',
            56
        );
        
        add_submenu_page(
            'labasino-sms',
            'داشبورد',
            'داشبورد',
            'manage_options',
            'labasino-sms',
            array($this, 'render_dashboard_page')
        );
        
        add_submenu_page(
            'labasino-sms',
            'تنظیمات',
            'تنظیمات',
            'manage_options',
            'labasino-sms-settings',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'labasino-sms',
            'لاگ ارسال‌ها',
            'لاگ ارسال‌ها',
            'manage_options',
            'labasino-sms-logs',
            array($this, 'render_logs_page')
        );
        
        add_submenu_page(
            'labasino-sms',
            'ارسال گروهی',
            'ارسال گروهی',
            'manage_options',
            'labasino-sms-bulk',
            array($this, 'render_bulk_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        // General Settings
        register_setting('labasino_sms_general', 'labasino_sms_gateway');
        register_setting('labasino_sms_general', 'labasino_sms_admin_mobile');
        register_setting('labasino_sms_general', 'labasino_sms_enable_logging');
        
        // Gateway Settings
        $gateways = array('kavenegar', 'melipayamak', 'farazsms', 'smsir', 'ghasedak');
        foreach ($gateways as $gateway) {
            register_setting('labasino_sms_gateway_' . $gateway, 'labasino_sms_gateway_' . $gateway);
        }
        
        // OTP Settings
        register_setting('labasino_sms_otp', 'labasino_sms_enable_otp');
        register_setting('labasino_sms_otp', 'labasino_sms_otp_length');
        register_setting('labasino_sms_otp', 'labasino_sms_otp_expiry');
        register_setting('labasino_sms_otp', 'labasino_sms_otp_limit');
        register_setting('labasino_sms_otp', 'labasino_sms_otp_limit_time');
        register_setting('labasino_sms_otp', 'labasino_sms_send_welcome');
        register_setting('labasino_sms_otp', 'labasino_sms_welcome_template');
        
        // Notification Settings
        $statuses = array('new_order', 'pending', 'processing', 'on_hold', 'completed', 'cancelled', 'refunded', 'failed', 'payment_complete');
        foreach ($statuses as $status) {
            register_setting('labasino_sms_notifications', 'labasino_sms_notify_' . $status);
            register_setting('labasino_sms_notifications', 'labasino_sms_template_customer_' . $status);
            register_setting('labasino_sms_notifications', 'labasino_sms_template_admin_' . $status);
        }
        
        // Appearance Settings
        register_setting('labasino_sms_appearance', 'labasino_sms_primary_color');
        register_setting('labasino_sms_appearance', 'labasino_sms_font_family');
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard_page() {
        Labasino_SMS_Admin_Dashboard::get_instance()->render();
    }
    
    /**
     * Render logs page
     */
    public function render_logs_page() {
        Labasino_SMS_Admin_Logs::get_instance()->render();
    }
    
    /**
     * Render bulk SMS page
     */
    public function render_bulk_page() {
        Labasino_SMS_Admin_Bulk_SMS::get_instance()->render();
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';
        ?>
        <div class="wrap labasino-sms-settings">
            <h1>تنظیمات Labasino SMS</h1>
            
            <nav class="nav-tab-wrapper">
                <a href="?page=labasino-sms-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">
                    عمومی
                </a>
                <a href="?page=labasino-sms-settings&tab=gateways" class="nav-tab <?php echo $active_tab === 'gateways' ? 'nav-tab-active' : ''; ?>">
                    درگاه‌های SMS
                </a>
                <a href="?page=labasino-sms-settings&tab=otp" class="nav-tab <?php echo $active_tab === 'otp' ? 'nav-tab-active' : ''; ?>">
                    تنظیمات OTP
                </a>
                <a href="?page=labasino-sms-settings&tab=notifications" class="nav-tab <?php echo $active_tab === 'notifications' ? 'nav-tab-active' : ''; ?>">
                    اعلان‌های سفارش
                </a>
                <a href="?page=labasino-sms-settings&tab=appearance" class="nav-tab <?php echo $active_tab === 'appearance' ? 'nav-tab-active' : ''; ?>">
                    ظاهر و رنگ‌بندی
                </a>
            </nav>
            
            <div class="tab-content">
                <?php
                switch ($active_tab) {
                    case 'general':
                        $this->render_general_settings();
                        break;
                    case 'gateways':
                        $this->render_gateway_settings();
                        break;
                    case 'otp':
                        $this->render_otp_settings();
                        break;
                    case 'notifications':
                        $this->render_notification_settings();
                        break;
                    case 'appearance':
                        $this->render_appearance_settings();
                        break;
                }
                ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render general settings
     */
    private function render_general_settings() {
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('labasino_sms_general'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">درگاه SMS فعال</th>
                    <td>
                        <select name="labasino_sms_gateway">
                            <?php
                            $gateways = Labasino_SMS_Gateway_Manager::get_instance()->get_gateways();
                            $active_gateway = get_option('labasino_sms_gateway', 'kavenegar');
                            foreach ($gateways as $id => $gateway) {
                                printf(
                                    '<option value="%s" %s>%s</option>',
                                    esc_attr($id),
                                    selected($active_gateway, $id, false),
                                    esc_html($gateway->get_name())
                                );
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">شماره موبایل مدیر</th>
                    <td>
                        <input type="text" name="labasino_sms_admin_mobile" 
                               value="<?php echo esc_attr(get_option('labasino_sms_admin_mobile', '')); ?>" 
                               class="regular-text" 
                               placeholder="09123456789" />
                        <p class="description">برای چند شماره از کاما (،) استفاده کنید</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">فعال‌سازی لاگ</th>
                    <td>
                        <label>
                            <input type="checkbox" name="labasino_sms_enable_logging" value="yes" 
                                   <?php checked(get_option('labasino_sms_enable_logging', 'yes'), 'yes'); ?> />
                            ذخیره لاگ ارسال پیامک‌ها
                        </label>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <?php
    }
    
    /**
     * Render gateway settings
     */
    private function render_gateway_settings() {
        $gateway_id = isset($_GET['gateway']) ? sanitize_text_field($_GET['gateway']) : 'kavenegar';
        $gateways = Labasino_SMS_Gateway_Manager::get_instance()->get_gateways();
        ?>
        <div class="gateway-selector">
            <h3>انتخاب درگاه:</h3>
            <?php foreach ($gateways as $id => $gateway): ?>
                <a href="?page=labasino-sms-settings&tab=gateways&gateway=<?php echo esc_attr($id); ?>" 
                   class="button <?php echo $gateway_id === $id ? 'button-primary' : ''; ?>">
                    <?php echo esc_html($gateway->get_name()); ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <form method="post" action="options.php" style="margin-top: 20px;">
            <?php settings_fields('labasino_sms_gateway_' . $gateway_id); ?>
            <table class="form-table">
                <?php
                // Render gateway-specific fields
                switch ($gateway_id) {
                    case 'kavenegar':
                        $this->render_kavenegar_fields();
                        break;
                    case 'melipayamak':
                        $this->render_melipayamak_fields();
                        break;
                    case 'farazsms':
                        $this->render_farazsms_fields();
                        break;
                    case 'smsir':
                        $this->render_smsir_fields();
                        break;
                    case 'ghasedak':
                        $this->render_ghasedak_fields();
                        break;
                }
                ?>
            </table>
            <?php submit_button('ذخیره تنظیمات'); ?>
            
            <div class="test-sms-section">
                <h3>تست ارسال پیامک</h3>
                <p>
                    <input type="text" id="test-mobile" placeholder="09123456789" class="regular-text" />
                    <button type="button" class="button" id="test-sms-btn">ارسال پیام تست</button>
                </p>
                <div id="test-sms-result"></div>
            </div>
        </form>
        
        <script>
        jQuery(document).ready(function($) {
            $('#test-sms-btn').on('click', function() {
                var mobile = $('#test-mobile').val();
                if (!mobile) {
                    alert('لطفاً شماره موبایل را وارد کنید');
                    return;
                }
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'labasino_test_sms',
                        nonce: labasinoSMS.nonce,
                        mobile: mobile
                    },
                    beforeSend: function() {
                        $('#test-sms-btn').prop('disabled', true).text('در حال ارسال...');
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#test-sms-result').html('<div class="notice notice-success"><p>' + response.data.message + '</p></div>');
                        } else {
                            $('#test-sms-result').html('<div class="notice notice-error"><p>' + response.data.message + '</p></div>');
                        }
                    },
                    complete: function() {
                        $('#test-sms-btn').prop('disabled', false).text('ارسال پیام تست');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render Kavenegar fields
     */
    private function render_kavenegar_fields() {
        $settings = get_option('labasino_sms_gateway_kavenegar', array());
        ?>
        <tr>
            <th scope="row">API Key <span class="required">*</span></th>
            <td>
                <input type="text" name="labasino_sms_gateway_kavenegar[api_key]" 
                       value="<?php echo esc_attr(isset($settings['api_key']) ? $settings['api_key'] : ''); ?>" 
                       class="regular-text" required />
                <p class="description">از پنل کاوه نگار دریافت کنید</p>
            </td>
        </tr>
        <tr>
            <th scope="row">شماره فرستنده</th>
            <td>
                <input type="text" name="labasino_sms_gateway_kavenegar[sender]" 
                       value="<?php echo esc_attr(isset($settings['sender']) ? $settings['sender'] : ''); ?>" 
                       class="regular-text" placeholder="10004346" />
            </td>
        </tr>
        <tr>
            <th scope="row">الگوی OTP</th>
            <td>
                <input type="text" name="labasino_sms_gateway_kavenegar[otp_template]" 
                       value="<?php echo esc_attr(isset($settings['otp_template']) ? $settings['otp_template'] : 'verify'); ?>" 
                       class="regular-text" placeholder="verify" />
                <p class="description">نام الگوی Lookup برای ارسال OTP</p>
            </td>
        </tr>
        <?php
    }
    
    /**
     * Render Melipayamak fields
     */
    private function render_melipayamak_fields() {
        $settings = get_option('labasino_sms_gateway_melipayamak', array());
        ?>
        <tr>
            <th scope="row">نام کاربری <span class="required">*</span></th>
            <td>
                <input type="text" name="labasino_sms_gateway_melipayamak[username]" 
                       value="<?php echo esc_attr(isset($settings['username']) ? $settings['username'] : ''); ?>" 
                       class="regular-text" required />
            </td>
        </tr>
        <tr>
            <th scope="row">رمز عبور <span class="required">*</span></th>
            <td>
                <input type="password" name="labasino_sms_gateway_melipayamak[password]" 
                       value="<?php echo esc_attr(isset($settings['password']) ? $settings['password'] : ''); ?>" 
                       class="regular-text" required />
            </td>
        </tr>
        <tr>
            <th scope="row">شماره فرستنده</th>
            <td>
                <input type="text" name="labasino_sms_gateway_melipayamak[sender]" 
                       value="<?php echo esc_attr(isset($settings['sender']) ? $settings['sender'] : ''); ?>" 
                       class="regular-text" placeholder="5000xxx" />
            </td>
        </tr>
        <tr>
            <th scope="row">کد الگوی OTP</th>
            <td>
                <input type="text" name="labasino_sms_gateway_melipayamak[otp_pattern]" 
                       value="<?php echo esc_attr(isset($settings['otp_pattern']) ? $settings['otp_pattern'] : ''); ?>" 
                       class="regular-text" placeholder="123456" />
            </td>
        </tr>
        <?php
    }
    
    /**
     * Render FarazSMS fields
     */
    private function render_farazsms_fields() {
        $settings = get_option('labasino_sms_gateway_farazsms', array());
        ?>
        <tr>
            <th scope="row">API Key <span class="required">*</span></th>
            <td>
                <input type="text" name="labasino_sms_gateway_farazsms[api_key]" 
                       value="<?php echo esc_attr(isset($settings['api_key']) ? $settings['api_key'] : ''); ?>" 
                       class="regular-text" required />
            </td>
        </tr>
        <tr>
            <th scope="row">شماره فرستنده</th>
            <td>
                <input type="text" name="labasino_sms_gateway_farazsms[sender]" 
                       value="<?php echo esc_attr(isset($settings['sender']) ? $settings['sender'] : ''); ?>" 
                       class="regular-text" placeholder="+983000xxxxx" />
            </td>
        </tr>
        <tr>
            <th scope="row">کد الگوی OTP</th>
            <td>
                <input type="text" name="labasino_sms_gateway_farazsms[otp_pattern]" 
                       value="<?php echo esc_attr(isset($settings['otp_pattern']) ? $settings['otp_pattern'] : ''); ?>" 
                       class="regular-text" />
            </td>
        </tr>
        <?php
    }
    
    /**
     * Render SMS.ir fields
     */
    private function render_smsir_fields() {
        $settings = get_option('labasino_sms_gateway_smsir', array());
        ?>
        <tr>
            <th scope="row">API Key <span class="required">*</span></th>
            <td>
                <input type="text" name="labasino_sms_gateway_smsir[api_key]" 
                       value="<?php echo esc_attr(isset($settings['api_key']) ? $settings['api_key'] : ''); ?>" 
                       class="regular-text" required />
            </td>
        </tr>
        <tr>
            <th scope="row">Secret Key <span class="required">*</span></th>
            <td>
                <input type="password" name="labasino_sms_gateway_smsir[secret_key]" 
                       value="<?php echo esc_attr(isset($settings['secret_key']) ? $settings['secret_key'] : ''); ?>" 
                       class="regular-text" required />
            </td>
        </tr>
        <tr>
            <th scope="row">شماره فرستنده</th>
            <td>
                <input type="text" name="labasino_sms_gateway_smsir[sender]" 
                       value="<?php echo esc_attr(isset($settings['sender']) ? $settings['sender'] : ''); ?>" 
                       class="regular-text" placeholder="30007732xxxxx" />
            </td>
        </tr>
        <tr>
            <th scope="row">شناسه الگوی OTP</th>
            <td>
                <input type="text" name="labasino_sms_gateway_smsir[otp_template]" 
                       value="<?php echo esc_attr(isset($settings['otp_template']) ? $settings['otp_template'] : ''); ?>" 
                       class="regular-text" placeholder="123456" />
            </td>
        </tr>
        <?php
    }
    
    /**
     * Render Ghasedak fields
     */
    private function render_ghasedak_fields() {
        $settings = get_option('labasino_sms_gateway_ghasedak', array());
        ?>
        <tr>
            <th scope="row">API Key <span class="required">*</span></th>
            <td>
                <input type="text" name="labasino_sms_gateway_ghasedak[api_key]" 
                       value="<?php echo esc_attr(isset($settings['api_key']) ? $settings['api_key'] : ''); ?>" 
                       class="regular-text" required />
            </td>
        </tr>
        <tr>
            <th scope="row">شماره فرستنده</th>
            <td>
                <input type="text" name="labasino_sms_gateway_ghasedak[sender]" 
                       value="<?php echo esc_attr(isset($settings['sender']) ? $settings['sender'] : ''); ?>" 
                       class="regular-text" />
            </td>
        </tr>
        <tr>
            <th scope="row">نام الگوی OTP</th>
            <td>
                <input type="text" name="labasino_sms_gateway_ghasedak[otp_template]" 
                       value="<?php echo esc_attr(isset($settings['otp_template']) ? $settings['otp_template'] : ''); ?>" 
                       class="regular-text" placeholder="otp" />
            </td>
        </tr>
        <?php
    }
    
    /**
     * Render OTP settings
     */
    private function render_otp_settings() {
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('labasino_sms_otp'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">فعال‌سازی OTP</th>
                    <td>
                        <label>
                            <input type="checkbox" name="labasino_sms_enable_otp" value="yes" 
                                   <?php checked(get_option('labasino_sms_enable_otp', 'yes'), 'yes'); ?> />
                            فعال‌سازی ورود و ثبت‌نام با OTP
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">طول کد OTP</th>
                    <td>
                        <input type="number" name="labasino_sms_otp_length" 
                               value="<?php echo esc_attr(get_option('labasino_sms_otp_length', 6)); ?>" 
                               min="4" max="8" />
                        <p class="description">تعداد ارقام کد یکبار مصرف (4-8)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">مدت اعتبار OTP</th>
                    <td>
                        <input type="number" name="labasino_sms_otp_expiry" 
                               value="<?php echo esc_attr(get_option('labasino_sms_otp_expiry', 2)); ?>" 
                               min="1" max="10" /> دقیقه
                    </td>
                </tr>
                <tr>
                    <th scope="row">محدودیت ارسال</th>
                    <td>
                        حداکثر 
                        <input type="number" name="labasino_sms_otp_limit" 
                               value="<?php echo esc_attr(get_option('labasino_sms_otp_limit', 3)); ?>" 
                               min="1" max="10" style="width: 60px;" /> 
                        درخواست در 
                        <input type="number" name="labasino_sms_otp_limit_time" 
                               value="<?php echo esc_attr(get_option('labasino_sms_otp_limit_time', 10)); ?>" 
                               min="1" max="60" style="width: 60px;" /> 
                        دقیقه
                        <p class="description">جلوگیری از سوءاستفاده</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">پیام خوش‌آمدگویی</th>
                    <td>
                        <label>
                            <input type="checkbox" name="labasino_sms_send_welcome" value="yes" 
                                   <?php checked(get_option('labasino_sms_send_welcome', 'yes'), 'yes'); ?> />
                            ارسال پیام خوش‌آمدگویی بعد از ثبت‌نام
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">متن پیام خوش‌آمدگویی</th>
                    <td>
                        <textarea name="labasino_sms_welcome_template" rows="3" class="large-text"><?php 
                            echo esc_textarea(get_option('labasino_sms_welcome_template', 'سلام {name}، به {shop_name} خوش آمدید!')); 
                        ?></textarea>
                        <p class="description">متغیرها: {name}, {shop_name}</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <?php
    }
    
    /**
     * Render notification settings
     */
    private function render_notification_settings() {
        $statuses = array(
            'new_order' => 'سفارش جدید (به مدیر)',
            'pending' => 'در انتظار پرداخت',
            'processing' => 'در حال پردازش',
            'on_hold' => 'در حالت تعلیق',
            'completed' => 'تکمیل شده',
            'cancelled' => 'لغو شده',
            'refunded' => 'مرجوع شده',
            'failed' => 'ناموفق',
            'payment_complete' => 'پرداخت موفق',
        );
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('labasino_sms_notifications'); ?>
            
            <h3>تنظیمات اعلان‌ها</h3>
            <table class="form-table">
                <?php foreach ($statuses as $status => $label): ?>
                <tr>
                    <th scope="row"><?php echo esc_html($label); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="labasino_sms_notify_<?php echo esc_attr($status); ?>" value="yes" 
                                   <?php checked(get_option('labasino_sms_notify_' . $status, 'yes'), 'yes'); ?> />
                            فعال
                        </label>
                        
                        <?php if ($status !== 'new_order'): ?>
                        <div style="margin-top: 10px;">
                            <strong>متن پیامک به مشتری:</strong><br>
                            <textarea name="labasino_sms_template_customer_<?php echo esc_attr($status); ?>" 
                                      rows="2" class="large-text" style="margin-top: 5px;"><?php 
                                echo esc_textarea(get_option('labasino_sms_template_customer_' . $status, '')); 
                            ?></textarea>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($status === 'new_order'): ?>
                        <div style="margin-top: 10px;">
                            <strong>متن پیامک به مدیر:</strong><br>
                            <textarea name="labasino_sms_template_admin_<?php echo esc_attr($status); ?>" 
                                      rows="2" class="large-text" style="margin-top: 5px;"><?php 
                                echo esc_textarea(get_option('labasino_sms_template_admin_' . $status, '')); 
                            ?></textarea>
                        </div>
                        <?php endif; ?>
                        
                        <p class="description" style="margin-top: 5px;">
                            متغیرها: {order_id}, {customer_name}, {order_total}, {order_status}, {shop_name}, {order_items}
                        </p>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php submit_button(); ?>
        </form>
        <?php
    }
    
    /**
     * Render appearance settings
     */
    private function render_appearance_settings() {
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('labasino_sms_appearance'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">رنگ اصلی</th>
                    <td>
                        <input type="color" name="labasino_sms_primary_color" 
                               value="<?php echo esc_attr(get_option('labasino_sms_primary_color', '#e74c3c')); ?>" />
                        <p class="description">رنگ دکمه‌ها و عناصر اصلی فرم ورود</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">فونت</th>
                    <td>
                        <select name="labasino_sms_font_family">
                            <?php
                            $fonts = array(
                                'IRANSans' => 'ایران سنس (IRANSans)',
                                'Vazir' => 'وزیر (Vazir)',
                                'Yekan' => 'یکان (Yekan)',
                            );
                            $current_font = get_option('labasino_sms_font_family', 'IRANSans');
                            foreach ($fonts as $value => $label) {
                                printf(
                                    '<option value="%s" %s>%s</option>',
                                    esc_attr($value),
                                    selected($current_font, $value, false),
                                    esc_html($label)
                                );
                            }
                            ?>
                        </select>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <?php
    }
    
    /**
     * AJAX: Test SMS
     */
    public function ajax_test_sms() {
        check_ajax_referer('labasino-sms-admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
        }
        
        $mobile = isset($_POST['mobile']) ? sanitize_text_field($_POST['mobile']) : '';
        
        if (empty($mobile)) {
            wp_send_json_error(array('message' => 'شماره موبایل الزامی است'));
        }
        
        $message = 'این یک پیام تست از افزونه Labasino SMS است.';
        
        $gateway = Labasino_SMS_Gateway_Manager::get_instance();
        $result = $gateway->send($mobile, $message);
        
        if ($result['success']) {
            wp_send_json_success(array('message' => 'پیامک با موفقیت ارسال شد'));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
}
<?php
/**
 * Admin Bulk SMS Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Admin_Bulk_SMS {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('wp_ajax_labasino_send_bulk_sms', array($this, 'ajax_send_bulk_sms'));
        add_action('wp_ajax_labasino_get_customers', array($this, 'ajax_get_customers'));
    }
    
    /**
     * Render bulk SMS page
     */
    public function render() {
        ?>
        <div class="wrap labasino-sms-bulk">
            <h1>ارسال پیامک گروهی</h1>
            
            <div class="bulk-sms-container">
                <form id="bulk-sms-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">گروه مخاطبین <span class="required">*</span></th>
                            <td>
                                <select name="recipient_group" id="recipient-group" required>
                                    <option value="">انتخاب کنید</option>
                                    <option value="all_customers">همه مشتریان</option>
                                    <option value="customers_with_orders">مشتریان دارای سفارش</option>
                                    <option value="customers_no_orders">مشتریان بدون سفارش</option>
                                    <option value="recent_customers">مشتریان اخیر (30 روز)</option>
                                    <option value="custom">شماره‌های دلخواه</option>
                                </select>
                                <p class="description">انتخاب گروه دریافت‌کنندگان</p>
                            </td>
                        </tr>
                        
                        <tr id="custom-numbers-row" style="display: none;">
                            <th scope="row">شماره‌های موبایل</th>
                            <td>
                                <textarea name="custom_numbers" id="custom-numbers" rows="5" class="large-text" 
                                          placeholder="09123456789&#10;09121234567&#10;..."></textarea>
                                <p class="description">هر شماره در یک خط جداگانه</p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">متن پیامک <span class="required">*</span></th>
                            <td>
                                <textarea name="message" id="bulk-message" rows="5" class="large-text" 
                                          required placeholder="متن پیامک خود را وارد کنید..."></textarea>
                                <p class="description">
                                    تعداد کاراکتر: <span id="char-count">0</span> | 
                                    تعداد پیامک: <span id="sms-count">0</span>
                                </p>
                                <p class="description">
                                    متغیرهای قابل استفاده: {name}, {shop_name}
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">زمان ارسال</th>
                            <td>
                                <label>
                                    <input type="radio" name="send_time" value="now" checked /> هم‌اکنون
                                </label>
                                <label style="margin-right: 20px;">
                                    <input type="radio" name="send_time" value="schedule" /> زمان‌بندی شده
                                </label>
                                <div id="schedule-time-row" style="display: none; margin-top: 10px;">
                                    <input type="datetime-local" name="schedule_time" id="schedule-time" />
                                </div>
                            </td>
                        </tr>
                    </table>
                    
                    <div class="recipients-preview" id="recipients-preview" style="display: none;">
                        <h3>پیش‌نمایش دریافت‌کنندگان</h3>
                        <p>تعداد: <strong id="recipients-count">0</strong> نفر</p>
                        <div id="recipients-list" style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px;"></div>
                    </div>
                    
                    <p class="submit">
                        <button type="button" class="button" id="preview-btn">پیش‌نمایش دریافت‌کنندگان</button>
                        <button type="submit" class="button button-primary" id="send-btn">ارسال پیامک</button>
                    </p>
                </form>
                
                <div id="bulk-sms-result" style="margin-top: 20px;"></div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Character count
            $('#bulk-message').on('input', function() {
                var text = $(this).val();
                var charCount = text.length;
                var smsCount = Math.ceil(charCount / 70);
                
                $('#char-count').text(charCount);
                $('#sms-count').text(smsCount);
            });
            
            // Toggle custom numbers
            $('#recipient-group').on('change', function() {
                if ($(this).val() === 'custom') {
                    $('#custom-numbers-row').show();
                } else {
                    $('#custom-numbers-row').hide();
                }
            });
            
            // Toggle schedule time
            $('input[name="send_time"]').on('change', function() {
                if ($(this).val() === 'schedule') {
                    $('#schedule-time-row').show();
                } else {
                    $('#schedule-time-row').hide();
                }
            });
            
            // Preview recipients
            $('#preview-btn').on('click', function() {
                var group = $('#recipient-group').val();
                var customNumbers = $('#custom-numbers').val();
                
                if (!group) {
                    alert('لطفاً گروه مخاطبین را انتخاب کنید');
                    return;
                }
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'labasino_get_customers',
                        nonce: labasinoSMS.nonce,
                        group: group,
                        custom_numbers: customNumbers
                    },
                    beforeSend: function() {
                        $('#preview-btn').prop('disabled', true).text('در حال بارگذاری...');
                    },
                    success: function(response) {
                        if (response.success) {
                            var customers = response.data.customers;
                            $('#recipients-count').text(customers.length);
                            
                            var html = '<ul style="margin: 0; padding: 0; list-style: none;">';
                            customers.forEach(function(customer) {
                                html += '<li style="padding: 5px; border-bottom: 1px solid #eee;">';
                                html += customer.name + ' - ' + customer.mobile;
                                html += '</li>';
                            });
                            html += '</ul>';
                            
                            $('#recipients-list').html(html);
                            $('#recipients-preview').slideDown();
                        } else {
                            alert(response.data.message);
                        }
                    },
                    complete: function() {
                        $('#preview-btn').prop('disabled', false).text('پیش‌نمایش دریافت‌کنندگان');
                    }
                });
            });
            
            // Send bulk SMS
            $('#bulk-sms-form').on('submit', function(e) {
                e.preventDefault();
                
                if (!confirm('آیا از ارسال پیامک گروهی مطمئن هستید?')) {
                    return;
                }
                
                var formData = {
                    action: 'labasino_send_bulk_sms',
                    nonce: labasinoSMS.nonce,
                    recipient_group: $('#recipient-group').val(),
                    custom_numbers: $('#custom-numbers').val(),
                    message: $('#bulk-message').val(),
                    send_time: $('input[name="send_time"]:checked').val(),
                    schedule_time: $('#schedule-time').val()
                };
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: formData,
                    beforeSend: function() {
                        $('#send-btn').prop('disabled', true).text('در حال ارسال...');
                        $('#bulk-sms-result').html('<div class="notice notice-info"><p>در حال ارسال پیامک‌ها...</p></div>');
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#bulk-sms-result').html(
                                '<div class="notice notice-success"><p>' + response.data.message + '</p></div>'
                            );
                            $('#bulk-sms-form')[0].reset();
                            $('#recipients-preview').hide();
                        } else {
                            $('#bulk-sms-result').html(
                                '<div class="notice notice-error"><p>' + response.data.message + '</p></div>'
                            );
                        }
                    },
                    error: function() {
                        $('#bulk-sms-result').html(
                            '<div class="notice notice-error"><p>خطا در ارسال پیامک‌ها</p></div>'
                        );
                    },
                    complete: function() {
                        $('#send-btn').prop('disabled', false).text('ارسال پیامک');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * AJAX: Get customers
     */
    public function ajax_get_customers() {
        check_ajax_referer('labasino-sms-admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
        }
        
        $group = isset($_POST['group']) ? sanitize_text_field($_POST['group']) : '';
        $custom_numbers = isset($_POST['custom_numbers']) ? sanitize_textarea_field($_POST['custom_numbers']) : '';
        
        $customers = array();
        
        if ($group === 'custom') {
            $numbers = array_filter(array_map('trim', explode("\n", $custom_numbers)));
            foreach ($numbers as $mobile) {
                $customers[] = array(
                    'name' => 'شماره دلخواه',
                    'mobile' => $mobile
                );
            }
        } else {
            $args = array(
                'role' => 'customer',
                'number' => -1,
                'meta_query' => array(
                    array(
                        'key' => 'billing_phone',
                        'compare' => 'EXISTS'
                    )
                )
            );
            
            // Apply filters based on group
            switch ($group) {
                case 'recent_customers':
                    $args['date_query'] = array(
                        array(
                            'after' => '30 days ago',
                        ),
                    );
                    break;
            }
            
            $users = get_users($args);
            
            foreach ($users as $user) {
                $mobile = get_user_meta($user->ID, 'billing_phone', true);
                
                if (empty($mobile)) {
                    continue;
                }
                
                // Additional filters
                if ($group === 'customers_with_orders') {
                    $order_count = wc_get_customer_order_count($user->ID);
                    if ($order_count == 0) continue;
                }
                
                if ($group === 'customers_no_orders') {
                    $order_count = wc_get_customer_order_count($user->ID);
                    if ($order_count > 0) continue;
                }
                
                $customers[] = array(
                    'name' => $user->display_name,
                    'mobile' => $mobile
                );
            }
        }
        
        wp_send_json_success(array('customers' => $customers));
    }
    
    /**
     * AJAX: Send bulk SMS
     */
    public function ajax_send_bulk_sms() {
        check_ajax_referer('labasino-sms-admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
        }
        
        $group = isset($_POST['recipient_group']) ? sanitize_text_field($_POST['recipient_group']) : '';
        $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';
        $send_time = isset($_POST['send_time']) ? sanitize_text_field($_POST['send_time']) : 'now';
        
        if (empty($group) || empty($message)) {
            wp_send_json_error(array('message' => 'لطفاً تمام فیلدها را پر کنید'));
        }
        
        // Get customers (reuse the logic from ajax_get_customers)
        $_POST['group'] = $group;
        $_POST['nonce'] = wp_create_nonce('labasino-sms-admin');
        
        $this->ajax_get_customers();
        $response = json_decode(ob_get_clean(), true);
        
        if (!$response['success']) {
            wp_send_json_error(array('message' => 'خطا در دریافت لیست مخاطبین'));
        }
        
        $customers = $response['data']['customers'];
        
        if (empty($customers)) {
            wp_send_json_error(array('message' => 'هیچ مخاطبی یافت نشد'));
        }
        
        $gateway = Labasino_SMS_Gateway_Manager::get_instance();
        $success_count = 0;
        $failed_count = 0;
        
        foreach ($customers as $customer) {
            $mobile = $customer['mobile'];
            $personalized_message = str_replace(
                array('{name}', '{shop_name}'),
                array($customer['name'], get_bloginfo('name')),
                $message
            );
            
            $result = $gateway->send($mobile, $personalized_message);
            
            if ($result['success']) {
                $success_count++;
            } else {
                $failed_count++;
            }
            
            // Small delay to prevent rate limiting
            usleep(100000); // 0.1 second
        }
        
        wp_send_json_success(array(
            'message' => sprintf(
                'ارسال کامل شد. موفق: %d | ناموفق: %d',
                $success_count,
                $failed_count
            )
        ));
    }
}
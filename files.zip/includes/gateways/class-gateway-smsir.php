<?php
/**
 * SMS.ir Gateway Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Gateway_SMSir extends Labasino_SMS_Gateway_Abstract {
    
    /**
     * API endpoint
     */
    private $api_url = 'https://api.sms.ir/v1/';
    
    /**
     * Initialize gateway
     */
    protected function init() {
        $this->id = 'smsir';
        $this->name = 'اس ام اس ایر (SMS.ir)';
    }
    
    /**
     * Get access token
     */
    private function get_token() {
        $api_key = $this->get_setting('api_key');
        $secret_key = $this->get_setting('secret_key');
        
        if (empty($api_key) || empty($secret_key)) {
            return false;
        }
        
        // Check cached token
        $cached_token = get_transient('labasino_smsir_token');
        if ($cached_token) {
            return $cached_token;
        }
        
        $url = $this->api_url . 'Token/GetToken';
        
        $data = array(
            'UserApiKey' => $api_key,
            'SecretKey' => $secret_key
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($data)
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['TokenKey'])) {
            // Cache token for 25 minutes (tokens usually expire in 30 minutes)
            set_transient('labasino_smsir_token', $body['TokenKey'], 25 * MINUTE_IN_SECONDS);
            return $body['TokenKey'];
        }
        
        return false;
    }
    
    /**
     * Send SMS
     */
    public function send($mobile, $message) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $token = $this->get_token();
        
        if (!$token) {
            return array(
                'success' => false,
                'message' => 'عدم احراز هویت با سرور SMS.ir'
            );
        }
        
        $sender = $this->get_setting('sender');
        
        $url = $this->api_url . 'send/bulk';
        
        $data = array(
            'Messages' => array($message),
            'MobileNumbers' => array($mobile),
            'LineNumber' => $sender,
            'SendDateTime' => '',
            'CanContinueInCaseOfError' => false
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-sms-ir-secure-token' => $token
            ),
            'body' => json_encode($data)
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, $message, 'general', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['IsSuccessful']) && $body['IsSuccessful'] === true) {
            $this->log($mobile, $message, 'general', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'پیامک با موفقیت ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['Message']) ? $body['Message'] : 'خطای ناشناخته';
            $this->log($mobile, $message, 'general', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
    
    /**
     * Send OTP using Ultra Fast Send
     */
    public function send_otp($mobile, $code) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $token = $this->get_token();
        
        if (!$token) {
            return array(
                'success' => false,
                'message' => 'عدم احراز هویت با سرور SMS.ir'
            );
        }
        
        $template_id = $this->get_setting('otp_template');
        
        if (empty($template_id)) {
            // Fallback to regular SMS
            $message = sprintf('کد تایید شما: %s', $code);
            return $this->send($mobile, $message);
        }
        
        $url = $this->api_url . 'send/verify';
        
        $data = array(
            'Mobile' => $mobile,
            'TemplateId' => intval($template_id),
            'Parameters' => array(
                array(
                    'Name' => 'Code',
                    'Value' => $code
                )
            )
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-sms-ir-secure-token' => $token
            ),
            'body' => json_encode($data)
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['IsSuccessful']) && $body['IsSuccessful'] === true) {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'کد تایید ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['Message']) ? $body['Message'] : 'خطای ناشناخته';
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
}
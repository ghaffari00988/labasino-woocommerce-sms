<?php
/**
 * Admin Logs Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Admin_Logs {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('wp_ajax_labasino_delete_log', array($this, 'ajax_delete_log'));
        add_action('wp_ajax_labasino_clear_logs', array($this, 'ajax_clear_logs'));
    }
    
    /**
     * Render logs page
     */
    public function render() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'labasino_sms_log';
        
        // Filters
        $filter_status = isset($_GET['filter_status']) ? sanitize_text_field($_GET['filter_status']) : '';
        $filter_type = isset($_GET['filter_type']) ? sanitize_text_field($_GET['filter_type']) : '';
        $filter_gateway = isset($_GET['filter_gateway']) ? sanitize_text_field($_GET['filter_gateway']) : '';
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        // Build query
        $where = array('1=1');
        
        if (!empty($filter_status)) {
            $where[] = $wpdb->prepare('status = %s', $filter_status);
        }
        
        if (!empty($filter_type)) {
            $where[] = $wpdb->prepare('type = %s', $filter_type);
        }
        
        if (!empty($filter_gateway)) {
            $where[] = $wpdb->prepare('gateway = %s', $filter_gateway);
        }
        
        if (!empty($search)) {
            $where[] = $wpdb->prepare('(mobile LIKE %s OR message LIKE %s)', 
                '%' . $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%'
            );
        }
        
        $where_sql = implode(' AND ', $where);
        
        // Pagination
        $per_page = 50;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        
        // Get total
        $total = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE $where_sql");
        $total_pages = ceil($total / $per_page);
        
        // Get logs
        $logs = $wpdb->get_results(
            "SELECT * FROM $table WHERE $where_sql ORDER BY created_at DESC LIMIT $per_page OFFSET $offset"
        );
        
        ?>
        <div class="wrap labasino-sms-logs">
            <h1>
                لاگ ارسال پیامک‌ها
                <a href="#" class="page-title-action" id="clear-all-logs">پاک کردن همه</a>
            </h1>
            
            <!-- Filters -->
            <div class="tablenav top">
                <form method="get" class="labasino-filters">
                    <input type="hidden" name="page" value="labasino-sms-logs" />
                    
                    <select name="filter_status">
                        <option value="">همه وضعیت‌ها</option>
                        <option value="sent" <?php selected($filter_status, 'sent'); ?>>ارسال شده</option>
                        <option value="failed" <?php selected($filter_status, 'failed'); ?>>ناموفق</option>
                        <option value="pending" <?php selected($filter_status, 'pending'); ?>>در انتظار</option>
                    </select>
                    
                    <select name="filter_type">
                        <option value="">همه انواع</option>
                        <option value="otp" <?php selected($filter_type, 'otp'); ?>>OTP</option>
                        <option value="order" <?php selected($filter_type, 'order'); ?>>سفارش</option>
                        <option value="general" <?php selected($filter_type, 'general'); ?>>عمومی</option>
                    </select>
                    
                    <select name="filter_gateway">
                        <option value="">همه درگاه‌ها</option>
                        <?php
                        $gateways = Labasino_SMS_Gateway_Manager::get_instance()->get_gateways();
                        foreach ($gateways as $id => $gateway) {
                            printf(
                                '<option value="%s" %s>%s</option>',
                                esc_attr($id),
                                selected($filter_gateway, $id, false),
                                esc_html($gateway->get_name())
                            );
                        }
                        ?>
                    </select>
                    
                    <input type="search" name="s" value="<?php echo esc_attr($search); ?>" 
                           placeholder="جستجو در شماره یا پیام..." />
                    
                    <button type="submit" class="button">فیلتر</button>
                    
                    <?php if (!empty($filter_status) || !empty($filter_type) || !empty($filter_gateway) || !empty($search)): ?>
                        <a href="?page=labasino-sms-logs" class="button">پاک کردن فیلترها</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- Logs Table -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th>شماره موبایل</th>
                        <th>پیام</th>
                        <th>نوع</th>
                        <th>وضعیت</th>
                        <th>درگاه</th>
                        <th>زمان ارسال</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($logs)): ?>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log->id); ?></td>
                            <td dir="ltr"><?php echo esc_html($log->mobile); ?></td>
                            <td>
                                <div class="log-message" title="<?php echo esc_attr($log->message); ?>">
                                    <?php echo esc_html(mb_substr($log->message, 0, 60)) . (mb_strlen($log->message) > 60 ? '...' : ''); ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo esc_attr($log->type); ?>">
                                    <?php echo esc_html($this->get_type_label($log->type)); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($log->status === 'sent'): ?>
                                    <span class="badge badge-success">✓ ارسال شد</span>
                                <?php elseif ($log->status === 'failed'): ?>
                                    <span class="badge badge-danger">✗ ناموفق</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">در انتظار</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($log->gateway); ?></td>
                            <td dir="ltr"><?php echo esc_html(date_i18n('Y/m/d H:i:s', strtotime($log->created_at))); ?></td>
                            <td>
                                <a href="#" class="button button-small view-response" data-id="<?php echo esc_attr($log->id); ?>" 
                                   data-response="<?php echo esc_attr($log->response); ?>">
                                    مشاهده پاسخ
                                </a>
                                <a href="#" class="button button-small delete-log" data-id="<?php echo esc_attr($log->id); ?>">
                                    حذف
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px;">
                                <?php if (!empty($search) || !empty($filter_status) || !empty($filter_type) || !empty($filter_gateway)): ?>
                                    نتیجه‌ای یافت نشد
                                <?php else: ?>
                                    هنوز لاگی ثبت نشده است
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php printf('%s مورد', number_format($total)); ?></span>
                    <?php
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                        'total' => $total_pages,
                        'current' => $current_page
                    ));
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Response Modal -->
        <div id="response-modal" style="display: none;">
            <div class="response-modal-content">
                <span class="close-modal">&times;</span>
                <h2>پاسخ درگاه</h2>
                <pre id="response-content"></pre>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // View response
            $('.view-response').on('click', function(e) {
                e.preventDefault();
                var response = $(this).data('response');
                
                if (!response || response === 'null') {
                    $('#response-content').text('پاسخی ثبت نشده است');
                } else {
                    try {
                        var formatted = JSON.stringify(JSON.parse(response), null, 2);
                        $('#response-content').text(formatted);
                    } catch (e) {
                        $('#response-content').text(response);
                    }
                }
                
                $('#response-modal').fadeIn();
            });
            
            $('.close-modal, #response-modal').on('click', function(e) {
                if (e.target === this) {
                    $('#response-modal').fadeOut();
                }
            });
            
            // Delete log
            $('.delete-log').on('click', function(e) {
                e.preventDefault();
                
                if (!confirm('آیا از حذف این لاگ مطمئن هستید؟')) {
                    return;
                }
                
                var id = $(this).data('id');
                var row = $(this).closest('tr');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'labasino_delete_log',
                        nonce: labasinoSMS.nonce,
                        id: id
                    },
                    success: function(response) {
                        if (response.success) {
                            row.fadeOut(function() {
                                row.remove();
                            });
                        } else {
                            alert(response.data.message);
                        }
                    }
                });
            });
            
            // Clear all logs
            $('#clear-all-logs').on('click', function(e) {
                e.preventDefault();
                
                if (!confirm('آیا از حذف تمام لاگ‌ها مطمئن هستید؟ این عمل قابل بازگشت نیست!')) {
                    return;
                }
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'labasino_clear_logs',
                        nonce: labasinoSMS.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            alert(response.data.message);
                        }
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Get type label
     */
    private function get_type_label($type) {
        $labels = array(
            'otp' => 'OTP',
            'order' => 'سفارش',
            'general' => 'عمومی',
        );
        
        return isset($labels[$type]) ? $labels[$type] : $type;
    }
    
    /**
     * AJAX: Delete log
     */
    public function ajax_delete_log() {
        check_ajax_referer('labasino-sms-admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
        }
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        
        if (!$id) {
            wp_send_json_error(array('message' => 'شناسه نامعتبر'));
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'labasino_sms_log';
        
        $deleted = $wpdb->delete($table, array('id' => $id), array('%d'));
        
        if ($deleted) {
            wp_send_json_success(array('message' => 'لاگ حذف شد'));
        } else {
            wp_send_json_error(array('message' => 'خطا در حذف لاگ'));
        }
    }
    
    /**
     * AJAX: Clear all logs
     */
    public function ajax_clear_logs() {
        check_ajax_referer('labasino-sms-admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'دسترسی غیرمجاز'));
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'labasino_sms_log';
        
        $wpdb->query("TRUNCATE TABLE $table");
        
        wp_send_json_success(array('message' => 'تمام لاگ‌ها حذف شدند'));
    }
}
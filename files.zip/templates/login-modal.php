<?php
/**
 * Login Modal Template
 * Popup modal for login
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div id="labasino-login-modal" class="labasino-modal" style="display: none;">
    <div class="labasino-modal-overlay"></div>
    <div class="labasino-modal-content">
        <button type="button" class="labasino-modal-close">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
        </button>
        
        <?php include LABASINO_SMS_PLUGIN_DIR . 'templates/login-form.php'; ?>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Open modal on login links
    $('a[href*="my-account"], a[href*="customer/account"]').on('click', function(e) {
        if (!$('body').hasClass('logged-in')) {
            e.preventDefault();
            $('#labasino-login-modal').fadeIn(300);
        }
    });
    
    // Close modal
    $('.labasino-modal-close, .labasino-modal-overlay').on('click', function() {
        $('#labasino-login-modal').fadeOut(300);
    });
});
</script>
<?php
/**
 * Account Settings Class
 * Allows users to set password after OTP registration
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Account_Settings {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Add password settings to My Account
        add_action('woocommerce_account_dashboard', array($this, 'show_password_notice'));
        add_action('woocommerce_edit_account_form', array($this, 'add_mobile_field'));
        add_action('woocommerce_save_account_details', array($this, 'save_mobile_field'));
        
        // AJAX handler
        add_action('wp_ajax_labasino_set_password', array($this, 'ajax_set_password'));
    }
    
    /**
     * Show password notice for OTP-only users
     */
    public function show_password_notice() {
        $user_id = get_current_user_id();
        $otp_only = get_user_meta($user_id, 'labasino_otp_only', true);
        
        if ($otp_only === 'yes') {
            ?>
            <div class="woocommerce-message labasino-password-notice">
                <p>
                    <strong>توجه:</strong> حساب کاربری شما فقط با کد یکبار مصرف قابل ورود است.
                    برای فعال‌سازی ورود با رمز عبور، می‌توانید از بخش زیر اقدام کنید.
                </p>
                <button type="button" class="button" id="labasino-enable-password-btn">
                    فعال‌سازی رمز عبور
                </button>
            </div>
            
            <div id="labasino-password-form" style="display: none; margin-top: 20px;">
                <h3>تنظیم رمز عبور</h3>
                <form id="labasino-set-password-form">
                    <p class="form-row form-row-wide">
                        <label for="labasino_password">رمز عبور جدید <span class="required">*</span></label>
                        <input type="password" class="input-text" name="password" id="labasino_password" required />
                    </p>
                    <p class="form-row form-row-wide">
                        <label for="labasino_password_confirm">تکرار رمز عبور <span class="required">*</span></label>
                        <input type="password" class="input-text" name="password_confirm" id="labasino_password_confirm" required />
                    </p>
                    <p>
                        <button type="submit" class="button">ذخیره رمز عبور</button>
                    </p>
                </form>
            </div>
            
            <script>
            jQuery(document).ready(function($) {
                $('#labasino-enable-password-btn').on('click', function() {
                    $('#labasino-password-form').slideDown();
                    $(this).hide();
                });
                
                $('#labasino-set-password-form').on('submit', function(e) {
                    e.preventDefault();
                    
                    var password = $('#labasino_password').val();
                    var password_confirm = $('#labasino_password_confirm').val();
                    
                    if (password !== password_confirm) {
                        alert('رمز عبور و تکرار آن یکسان نیستند');
                        return;
                    }
                    
                    if (password.length < 6) {
                        alert('رمز عبور باید حداقل 6 کاراکتر باشد');
                        return;
                    }
                    
                    $.ajax({
                        url: labasinoSMS.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'labasino_set_password',
                            nonce: labasinoSMS.nonce,
                            password: password
                        },
                        beforeSend: function() {
                            $('#labasino-set-password-form button').prop('disabled', true).text('در حال ذخیره...');
                        },
                        success: function(response) {
                            if (response.success) {
                                alert(response.data.message);
                                location.reload();
                            } else {
                                alert(response.data.message);
                            }
                        },
                        error: function() {
                            alert('خطا در برقراری ارتباط با سرور');
                        },
                        complete: function() {
                            $('#labasino-set-password-form button').prop('disabled', false).text('ذخیره رمز عبور');
                        }
                    });
                });
            });
            </script>
            <?php
        }
    }
    
    /**
     * AJAX: Set password
     */
    public function ajax_set_password() {
        check_ajax_referer('labasino-sms-frontend', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'لطفاً ابتدا وارد شوید'));
        }
        
        $user_id = get_current_user_id();
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        
        if (empty($password)) {
            wp_send_json_error(array('message' => 'لطفاً رمز عبور را وارد کنید'));
        }
        
        if (strlen($password) < 6) {
            wp_send_json_error(array('message' => 'رمز عبور باید حداقل 6 کاراکتر باشد'));
        }
        
        // Set password
        wp_set_password($password, $user_id);
        
        // Remove OTP-only flag
        update_user_meta($user_id, 'labasino_otp_only', 'no');
        
        Labasino_SMS_Logger::success('User set password', array('user_id' => $user_id));
        
        wp_send_json_success(array(
            'message' => 'رمز عبور با موفقیت تنظیم شد. اکنون می‌توانید با رمز عبور وارد شوید.'
        ));
    }
    
    /**
     * Add mobile field to account form
     */
    public function add_mobile_field() {
        $user_id = get_current_user_id();
        $mobile = get_user_meta($user_id, 'billing_phone', true);
        $verified = get_user_meta($user_id, 'labasino_mobile_verified', true);
        ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="billing_phone">
                شماره موبایل 
                <?php if ($verified === 'yes'): ?>
                    <span style="color: green;">✓ تأیید شده</span>
                <?php endif; ?>
            </label>
            <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" 
                   name="billing_phone" id="billing_phone" 
                   value="<?php echo esc_attr($mobile); ?>" 
                   readonly />
            <small>برای تغییر شماره موبایل با پشتیبانی تماس بگیرید</small>
        </p>
        <?php
    }
    
    /**
     * Save mobile field
     */
    public function save_mobile_field($user_id) {
        // Mobile is readonly, so we don't update it here
        // Users must contact support to change mobile
    }
}
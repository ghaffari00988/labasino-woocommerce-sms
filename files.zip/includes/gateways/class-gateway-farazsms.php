<?php
/**
 * FarazSMS Gateway Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Gateway_FarazSMS extends Labasino_SMS_Gateway_Abstract {
    
    /**
     * API endpoint
     */
    private $api_url = 'https://api2.ippanel.com/api/v1/';
    
    /**
     * Initialize gateway
     */
    protected function init() {
        $this->id = 'farazsms';
        $this->name = 'فراز اس ام اس (FarazSMS)';
    }
    
    /**
     * Send SMS
     */
    public function send($mobile, $message) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $api_key = $this->get_setting('api_key');
        $sender = $this->get_setting('sender');
        
        if (empty($api_key)) {
            return array(
                'success' => false,
                'message' => 'API Key تنظیم نشده است'
            );
        }
        
        $url = $this->api_url . 'sms/send/webservice/single';
        
        $data = array(
            'recipient' => $mobile,
            'sender' => $sender,
            'message' => $message
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'apikey' => $api_key
            ),
            'body' => json_encode($data)
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, $message, 'general', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['status']) && $body['status'] == 'OK') {
            $this->log($mobile, $message, 'general', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'پیامک با موفقیت ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['message']) ? $body['message'] : 'خطای ناشناخته';
            $this->log($mobile, $message, 'general', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
    
    /**
     * Send OTP using Pattern
     */
    public function send_otp($mobile, $code) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $api_key = $this->get_setting('api_key');
        $pattern_code = $this->get_setting('otp_pattern');
        
        if (empty($api_key)) {
            return array(
                'success' => false,
                'message' => 'API Key تنظیم نشده است'
            );
        }
        
        if (empty($pattern_code)) {
            // Fallback to regular SMS
            $message = sprintf('کد تایید شما: %s', $code);
            return $this->send($mobile, $message);
        }
        
        $url = $this->api_url . 'sms/send/pattern';
        
        $data = array(
            'code' => $pattern_code,
            'recipient' => $mobile,
            'variable' => array(
                'verification-code' => $code
            )
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'apikey' => $api_key
            ),
            'body' => json_encode($data)
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['status']) && $body['status'] == 'OK') {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'کد تایید ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['message']) ? $body['message'] : 'خطای ناشناخته';
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
}
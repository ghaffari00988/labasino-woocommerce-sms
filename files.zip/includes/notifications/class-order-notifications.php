<?php
/**
 * Order Notifications Class
 * Send SMS notifications for order status changes
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Order_Notifications {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Order status hooks
        add_action('woocommerce_new_order', array($this, 'new_order_notification'), 10, 1);
        add_action('woocommerce_order_status_pending', array($this, 'order_status_pending'), 10, 1);
        add_action('woocommerce_order_status_processing', array($this, 'order_status_processing'), 10, 1);
        add_action('woocommerce_order_status_on-hold', array($this, 'order_status_on_hold'), 10, 1);
        add_action('woocommerce_order_status_completed', array($this, 'order_status_completed'), 10, 1);
        add_action('woocommerce_order_status_cancelled', array($this, 'order_status_cancelled'), 10, 1);
        add_action('woocommerce_order_status_refunded', array($this, 'order_status_refunded'), 10, 1);
        add_action('woocommerce_order_status_failed', array($this, 'order_status_failed'), 10, 1);
        
        // Payment hooks
        add_action('woocommerce_payment_complete', array($this, 'payment_complete'), 10, 1);
    }
    
    /**
     * New order notification (to admin)
     */
    public function new_order_notification($order_id) {
        if (!$this->is_notification_enabled('new_order')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        
        // Send to admin
        $this->send_admin_notification($order, 'new_order');
    }
    
    /**
     * Order status: Pending
     */
    public function order_status_pending($order_id) {
        if (!$this->is_notification_enabled('pending')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'pending');
    }
    
    /**
     * Order status: Processing
     */
    public function order_status_processing($order_id) {
        if (!$this->is_notification_enabled('processing')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'processing');
    }
    
    /**
     * Order status: On Hold
     */
    public function order_status_on_hold($order_id) {
        if (!$this->is_notification_enabled('on_hold')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'on_hold');
    }
    
    /**
     * Order status: Completed
     */
    public function order_status_completed($order_id) {
        if (!$this->is_notification_enabled('completed')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'completed');
    }
    
    /**
     * Order status: Cancelled
     */
    public function order_status_cancelled($order_id) {
        if (!$this->is_notification_enabled('cancelled')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'cancelled');
    }
    
    /**
     * Order status: Refunded
     */
    public function order_status_refunded($order_id) {
        if (!$this->is_notification_enabled('refunded')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'refunded');
    }
    
    /**
     * Order status: Failed
     */
    public function order_status_failed($order_id) {
        if (!$this->is_notification_enabled('failed')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'failed');
    }
    
    /**
     * Payment complete
     */
    public function payment_complete($order_id) {
        if (!$this->is_notification_enabled('payment_complete')) {
            return;
        }
        
        $order = wc_get_order($order_id);
        $this->send_customer_notification($order, 'payment_complete');
    }
    
    /**
     * Send customer notification
     */
    private function send_customer_notification($order, $status) {
        $mobile = $order->get_billing_phone();
        
        if (empty($mobile)) {
            Labasino_SMS_Logger::warning('No mobile number for order', array(
                'order_id' => $order->get_id()
            ));
            return;
        }
        
        $message = $this->get_message_template($order, $status, 'customer');
        
        if (empty($message)) {
            return;
        }
        
        $gateway = Labasino_SMS_Gateway_Manager::get_instance();
        $result = $gateway->send($mobile, $message);
        
        if ($result['success']) {
            Labasino_SMS_Logger::success('Order notification sent to customer', array(
                'order_id' => $order->get_id(),
                'status' => $status,
                'mobile' => $mobile
            ));
            
            // Add order note
            $order->add_order_note(sprintf('پیامک %s به مشتری ارسال شد', $this->get_status_label($status)));
        } else {
            Labasino_SMS_Logger::error('Failed to send order notification to customer', array(
                'order_id' => $order->get_id(),
                'status' => $status,
                'error' => $result['message']
            ));
        }
    }
    
    /**
     * Send admin notification
     */
    private function send_admin_notification($order, $status) {
        $admin_mobiles = get_option('labasino_sms_admin_mobile', '');
        
        if (empty($admin_mobiles)) {
            return;
        }
        
        $mobiles = array_map('trim', explode(',', $admin_mobiles));
        $message = $this->get_message_template($order, $status, 'admin');
        
        if (empty($message)) {
            return;
        }
        
        $gateway = Labasino_SMS_Gateway_Manager::get_instance();
        
        foreach ($mobiles as $mobile) {
            if (empty($mobile)) {
                continue;
            }
            
            $result = $gateway->send($mobile, $message);
            
            if ($result['success']) {
                Labasino_SMS_Logger::success('Order notification sent to admin', array(
                    'order_id' => $order->get_id(),
                    'status' => $status,
                    'mobile' => $mobile
                ));
            }
        }
    }
    
    /**
     * Get message template
     */
    private function get_message_template($order, $status, $recipient = 'customer') {
        $template_key = 'labasino_sms_template_' . $recipient . '_' . $status;
        $template = get_option($template_key, $this->get_default_template($status, $recipient));
        
        if (empty($template)) {
            return '';
        }
        
        return $this->parse_template($template, $order);
    }
    
    /**
     * Parse template variables
     */
    private function parse_template($template, $order) {
        $variables = array(
            '{order_id}' => $order->get_order_number(),
            '{order_date}' => $order->get_date_created()->date_i18n('Y/m/d H:i'),
            '{order_total}' => number_format($order->get_total()) . ' تومان',
            '{order_status}' => wc_get_order_status_name($order->get_status()),
            '{customer_name}' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            '{customer_first_name}' => $order->get_billing_first_name(),
            '{customer_last_name}' => $order->get_billing_last_name(),
            '{customer_mobile}' => $order->get_billing_phone(),
            '{customer_email}' => $order->get_billing_email(),
            '{shop_name}' => get_bloginfo('name'),
            '{shop_url}' => home_url(),
            '{payment_method}' => $order->get_payment_method_title(),
            '{shipping_method}' => $order->get_shipping_method(),
            '{tracking_code}' => $order->get_meta('_tracking_code', true),
        );
        
        // Get items
        $items = array();
        foreach ($order->get_items() as $item) {
            $items[] = $item->get_name() . ' × ' . $item->get_quantity();
        }
        $variables['{order_items}'] = implode('، ', $items);
        
        $message = str_replace(array_keys($variables), array_values($variables), $template);
        
        return apply_filters('labasino_sms_parsed_message', $message, $order);
    }
    
    /**
     * Get default template
     */
    private function get_default_template($status, $recipient = 'customer') {
        $defaults = array(
            'customer' => array(
                'new_order' => 'سلام {customer_first_name}، سفارش شما با کد {order_id} ثبت شد. مبلغ: {order_total}',
                'pending' => 'سفارش {order_id} در انتظار پرداخت است.',
                'processing' => 'سفارش {order_id} در حال پردازش است.',
                'on_hold' => 'سفارش {order_id} در حالت تعلیق قرار گرفت.',
                'completed' => 'سفارش {order_id} با موفقیت تکمیل شد. از خرید شما متشکریم!',
                'cancelled' => 'سفارش {order_id} لغو شد.',
                'refunded' => 'مبلغ سفارش {order_id} مرجوع شد.',
                'failed' => 'پرداخت سفارش {order_id} ناموفق بود.',
                'payment_complete' => 'پرداخت سفارش {order_id} با موفقیت انجام شد. مبلغ: {order_total}',
            ),
            'admin' => array(
                'new_order' => '🔔 سفارش جدید #{order_id}\nمشتری: {customer_name}\nمبلغ: {order_total}',
            ),
        );
        
        return isset($defaults[$recipient][$status]) ? $defaults[$recipient][$status] : '';
    }
    
    /**
     * Check if notification is enabled
     */
    private function is_notification_enabled($status) {
        return get_option('labasino_sms_notify_' . $status, 'yes') === 'yes';
    }
    
    /**
     * Get status label
     */
    private function get_status_label($status) {
        $labels = array(
            'new_order' => 'سفارش جدید',
            'pending' => 'در انتظار پرداخت',
            'processing' => 'در حال پردازش',
            'on_hold' => 'در حالت تعلیق',
            'completed' => 'تکمیل شده',
            'cancelled' => 'لغو شده',
            'refunded' => 'مرجوع شده',
            'failed' => 'ناموفق',
            'payment_complete' => 'پرداخت موفق',
        );
        
        return isset($labels[$status]) ? $labels[$status] : $status;
    }
}
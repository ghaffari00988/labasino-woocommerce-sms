<?php
/**
 * Gateway Manager Class
 * Manages all SMS gateways
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Gateway_Manager {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Available gateways
     */
    private $gateways = array();
    
    /**
     * Active gateway
     */
    private $active_gateway = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->register_gateways();
        $this->load_active_gateway();
    }
    
    /**
     * Register all gateways
     */
    private function register_gateways() {
        $this->gateways = array(
            'kavenegar' => new Labasino_SMS_Gateway_Kavenegar(),
            'melipayamak' => new Labasino_SMS_Gateway_Melipayamak(),
            'farazsms' => new Labasino_SMS_Gateway_FarazSMS(),
            'smsir' => new Labasino_SMS_Gateway_SMSir(),
            'ghasedak' => new Labasino_SMS_Gateway_Ghasedak(),
        );
        
        // Allow third-party gateways
        $this->gateways = apply_filters('labasino_sms_gateways', $this->gateways);
    }
    
    /**
     * Load active gateway
     */
    private function load_active_gateway() {
        $gateway_id = get_option('labasino_sms_gateway', 'kavenegar');
        
        if (isset($this->gateways[$gateway_id])) {
            $this->active_gateway = $this->gateways[$gateway_id];
        }
    }
    
    /**
     * Get all gateways
     */
    public function get_gateways() {
        return $this->gateways;
    }
    
    /**
     * Get active gateway
     */
    public function get_active_gateway() {
        return $this->active_gateway;
    }
    
    /**
     * Get gateway by ID
     */
    public function get_gateway($gateway_id) {
        return isset($this->gateways[$gateway_id]) ? $this->gateways[$gateway_id] : null;
    }
    
    /**
     * Send SMS using active gateway
     */
    public function send($mobile, $message) {
        if (!$this->active_gateway) {
            return array(
                'success' => false,
                'message' => 'هیچ درگاه فعالی انتخاب نشده است'
            );
        }
        
        return $this->active_gateway->send($mobile, $message);
    }
    
    /**
     * Send OTP using active gateway
     */
    public function send_otp($mobile, $code) {
        if (!$this->active_gateway) {
            return array(
                'success' => false,
                'message' => 'هیچ درگاه فعالی انتخاب نشده است'
            );
        }
        
        return $this->active_gateway->send_otp($mobile, $code);
    }
}
<?php
/**
 * Database Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Database {
    
    /**
     * Create database tables
     */
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // OTP Table
        $table_otp = $wpdb->prefix . 'labasino_sms_otp';
        $sql_otp = "CREATE TABLE IF NOT EXISTS $table_otp (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            mobile varchar(20) NOT NULL,
            code varchar(10) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime NOT NULL,
            verified tinyint(1) DEFAULT 0,
            attempts int(11) DEFAULT 0,
            ip_address varchar(45) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY mobile (mobile),
            KEY expires_at (expires_at)
        ) $charset_collate;";
        
        // SMS Log Table
        $table_log = $wpdb->prefix . 'labasino_sms_log';
        $sql_log = "CREATE TABLE IF NOT EXISTS $table_log (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            mobile varchar(20) NOT NULL,
            message text NOT NULL,
            gateway varchar(50) NOT NULL,
            type varchar(50) DEFAULT 'general',
            status varchar(20) DEFAULT 'pending',
            response text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            user_id bigint(20) DEFAULT NULL,
            order_id bigint(20) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY mobile (mobile),
            KEY gateway (gateway),
            KEY type (type),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Blacklist Table
        $table_blacklist = $wpdb->prefix . 'labasino_sms_blacklist';
        $sql_blacklist = "CREATE TABLE IF NOT EXISTS $table_blacklist (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            mobile varchar(20) NOT NULL,
            reason text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            created_by bigint(20) DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY mobile (mobile)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_otp);
        dbDelta($sql_log);
        dbDelta($sql_blacklist);
    }
    
    /**
     * Drop tables (for uninstall)
     */
    public static function drop_tables() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'labasino_sms_otp',
            $wpdb->prefix . 'labasino_sms_log',
            $wpdb->prefix . 'labasino_sms_blacklist'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
    }
}
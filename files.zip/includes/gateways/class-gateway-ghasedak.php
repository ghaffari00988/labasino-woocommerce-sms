<?php
/**
 * Ghasedak Gateway Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Gateway_Ghasedak extends Labasino_SMS_Gateway_Abstract {
    
    /**
     * API endpoint
     */
    private $api_url = 'https://api.ghasedak.me/v2/';
    
    /**
     * Initialize gateway
     */
    protected function init() {
        $this->id = 'ghasedak';
        $this->name = 'قاصدک (Ghasedak)';
    }
    
    /**
     * Send SMS
     */
    public function send($mobile, $message) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $api_key = $this->get_setting('api_key');
        $sender = $this->get_setting('sender');
        
        if (empty($api_key)) {
            return array(
                'success' => false,
                'message' => 'API Key تنظیم نشده است'
            );
        }
        
        $url = $this->api_url . 'sms/send/simple';
        
        $data = array(
            'message' => $message,
            'receptor' => $mobile,
            'linenumber' => $sender
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'apikey' => $api_key
            ),
            'body' => $data
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, $message, 'general', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['result']['code']) && $body['result']['code'] == 200) {
            $this->log($mobile, $message, 'general', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'پیامک با موفقیت ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['result']['message']) ? $body['result']['message'] : 'خطای ناشناخته';
            $this->log($mobile, $message, 'general', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
    
    /**
     * Send OTP using Verify API
     */
    public function send_otp($mobile, $code) {
        $mobile = $this->validate_mobile($mobile);
        
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        if ($this->is_blacklisted($mobile)) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل در لیست سیاه قرار دارد'
            );
        }
        
        $api_key = $this->get_setting('api_key');
        $template = $this->get_setting('otp_template');
        
        if (empty($api_key)) {
            return array(
                'success' => false,
                'message' => 'API Key تنظیم نشده است'
            );
        }
        
        if (empty($template)) {
            // Fallback to regular SMS
            $message = sprintf('کد تایید شما: %s', $code);
            return $this->send($mobile, $message);
        }
        
        $url = $this->api_url . 'verification/send/simple';
        
        $data = array(
            'receptor' => $mobile,
            'type' => '1',
            'template' => $template,
            'param1' => $code
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'apikey' => $api_key
            ),
            'body' => $data
        );
        
        $response = $this->http_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $response->get_error_message());
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['result']['code']) && $body['result']['code'] == 200) {
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'sent', $body);
            return array(
                'success' => true,
                'message' => 'کد تایید ارسال شد',
                'data' => $body
            );
        } else {
            $error_message = isset($body['result']['message']) ? $body['result']['message'] : 'خطای ناشناخته';
            $this->log($mobile, 'کد تایید: ' . $code, 'otp', 'failed', $body);
            return array(
                'success' => false,
                'message' => $error_message,
                'data' => $body
            );
        }
    }
}
<?php
/**
 * Admin Dashboard Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Admin_Dashboard {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Constructor
    }
    
    /**
     * Render dashboard
     */
    public function render() {
        global $wpdb;
        
        // Get statistics
        $table_log = $wpdb->prefix . 'labasino_sms_log';
        $table_otp = $wpdb->prefix . 'labasino_sms_otp';
        
        // Total SMS sent
        $total_sms = $wpdb->get_var("SELECT COUNT(*) FROM $table_log WHERE status = 'sent'");
        
        // SMS sent today
        $today_sms = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_log WHERE status = 'sent' AND DATE(created_at) = %s",
            current_time('Y-m-d')
        ));
        
        // Failed SMS
        $failed_sms = $wpdb->get_var("SELECT COUNT(*) FROM $table_log WHERE status = 'failed'");
        
        // OTP sent today
        $today_otp = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_otp WHERE DATE(created_at) = %s",
            current_time('Y-m-d')
        ));
        
        // Get last 7 days statistics
        $last_7_days = array();
        for ($i = 6; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime('-' . $i . ' days'));
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_log WHERE status = 'sent' AND DATE(created_at) = %s",
                $date
            ));
            $last_7_days[] = array(
                'date' => $date,
                'count' => intval($count)
            );
        }
        
        // Get SMS by type
        $sms_by_type = $wpdb->get_results(
            "SELECT type, COUNT(*) as count FROM $table_log WHERE status = 'sent' GROUP BY type ORDER BY count DESC LIMIT 5"
        );
        
        // Get recent logs
        $recent_logs = $wpdb->get_results(
            "SELECT * FROM $table_log ORDER BY created_at DESC LIMIT 10"
        );
        
        ?>
        <div class="wrap labasino-sms-dashboard">
            <h1>داشبورد Labasino SMS</h1>
            
            <!-- Statistics Cards -->
            <div class="labasino-stats-cards">
                <div class="stat-card stat-card-primary">
                    <div class="stat-icon">📊</div>
                    <div class="stat-content">
                        <h3><?php echo number_format($total_sms); ?></h3>
                        <p>کل پیامک‌های ارسال شده</p>
                    </div>
                </div>
                
                <div class="stat-card stat-card-success">
                    <div class="stat-icon">✅</div>
                    <div class="stat-content">
                        <h3><?php echo number_format($today_sms); ?></h3>
                        <p>پیامک‌های امروز</p>
                    </div>
                </div>
                
                <div class="stat-card stat-card-danger">
                    <div class="stat-icon">❌</div>
                    <div class="stat-content">
                        <h3><?php echo number_format($failed_sms); ?></h3>
                        <p>ارسال ناموفق</p>
                    </div>
                </div>
                
                <div class="stat-card stat-card-info">
                    <div class="stat-icon">🔐</div>
                    <div class="stat-content">
                        <h3><?php echo number_format($today_otp); ?></h3>
                        <p>OTP امروز</p>
                    </div>
                </div>
            </div>
            
            <!-- Charts Section -->
            <div class="labasino-charts-section">
                <div class="chart-container">
                    <h2>آمار ارسال پیامک (7 روز گذشته)</h2>
                    <canvas id="labasino-chart-weekly"></canvas>
                </div>
                
                <div class="chart-container">
                    <h2>پیامک‌ها بر اساس نوع</h2>
                    <canvas id="labasino-chart-types"></canvas>
                </div>
            </div>
            
            <!-- Recent Logs -->
            <div class="labasino-recent-logs">
                <h2>آخرین ارسال‌ها</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>شماره موبایل</th>
                            <th>پیام</th>
                            <th>نوع</th>
                            <th>وضعیت</th>
                            <th>درگاه</th>
                            <th>زمان</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recent_logs)): ?>
                            <?php foreach ($recent_logs as $log): ?>
                            <tr>
                                <td><?php echo esc_html($this->mask_mobile($log->mobile)); ?></td>
                                <td><?php echo esc_html(mb_substr($log->message, 0, 50)) . '...'; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo esc_attr($log->type); ?>">
                                        <?php echo esc_html($this->get_type_label($log->type)); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($log->status === 'sent'): ?>
                                        <span class="badge badge-success">✓ ارسال شد</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">✗ ناموفق</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($log->gateway); ?></td>
                                <td><?php echo esc_html(date_i18n('Y/m/d H:i', strtotime($log->created_at))); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center;">هنوز پیامکی ارسال نشده است</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <p style="text-align: center; margin-top: 20px;">
                    <a href="?page=labasino-sms-logs" class="button button-primary">مشاهده همه لاگ‌ها</a>
                </p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Weekly chart
            var weeklyData = <?php echo json_encode($last_7_days); ?>;
            var weeklyLabels = weeklyData.map(function(item) {
                return new Date(item.date).toLocaleDateString('fa-IR', {month: 'short', day: 'numeric'});
            });
            var weeklyCounts = weeklyData.map(function(item) {
                return item.count;
            });
            
            var weeklyCtx = document.getElementById('labasino-chart-weekly').getContext('2d');
            new Chart(weeklyCtx, {
                type: 'line',
                data: {
                    labels: weeklyLabels,
                    datasets: [{
                        label: 'تعداد پیامک',
                        data: weeklyCounts,
                        borderColor: '#e74c3c',
                        backgroundColor: 'rgba(231, 76, 60, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            
            // Types chart
            var typesData = <?php echo json_encode($sms_by_type); ?>;
            var typeLabels = typesData.map(function(item) {
                return item.type === 'otp' ? 'OTP' : 
                       item.type === 'order' ? 'سفارش' : 
                       item.type === 'general' ? 'عمومی' : item.type;
            });
            var typeCounts = typesData.map(function(item) {
                return parseInt(item.count);
            });
            
            var typesCtx = document.getElementById('labasino-chart-types').getContext('2d');
            new Chart(typesCtx, {
                type: 'doughnut',
                data: {
                    labels: typeLabels,
                    datasets: [{
                        data: typeCounts,
                        backgroundColor: [
                            '#e74c3c',
                            '#3498db',
                            '#2ecc71',
                            '#f39c12',
                            '#9b59b6'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Mask mobile number
     */
    private function mask_mobile($mobile) {
        if (strlen($mobile) === 11) {
            return substr($mobile, 0, 4) . '***' . substr($mobile, -4);
        }
        return $mobile;
    }
    
    /**
     * Get type label
     */
    private function get_type_label($type) {
        $labels = array(
            'otp' => 'OTP',
            'order' => 'سفارش',
            'general' => 'عمومی',
        );
        
        return isset($labels[$type]) ? $labels[$type] : $type;
    }
}
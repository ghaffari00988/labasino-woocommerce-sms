<?php
/**
 * Login Form Class
 * Beautiful Digikala-style login form
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Login_Form {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Replace default WooCommerce login form
        add_action('woocommerce_before_customer_login_form', array($this, 'remove_default_login_form'), 1);
        add_action('woocommerce_before_customer_login_form', array($this, 'render_login_form'));
        
        // Add login button to header
        add_action('wp_footer', array($this, 'render_login_modal'));
        
        // Shortcode for login form
        add_shortcode('labasino_login_form', array($this, 'login_form_shortcode'));
    }
    
    /**
     * Remove default login form
     */
    public function remove_default_login_form() {
        remove_action('woocommerce_before_customer_login_form', 'woocommerce_login_form');
        remove_action('woocommerce_before_customer_login_form', 'woocommerce_checkout_login_form');
    }
    
    /**
     * Render login form
     */
    public function render_login_form() {
        if (is_user_logged_in()) {
            return;
        }
        
        include LABASINO_SMS_PLUGIN_DIR . 'templates/login-form.php';
    }
    
    /**
     * Render login modal
     */
    public function render_login_modal() {
        if (is_user_logged_in()) {
            return;
        }
        
        include LABASINO_SMS_PLUGIN_DIR . 'templates/login-modal.php';
    }
    
    /**
     * Login form shortcode
     */
    public function login_form_shortcode($atts) {
        $atts = shortcode_atts(array(
            'redirect_to' => '',
        ), $atts);
        
        ob_start();
        
        if (is_user_logged_in()) {
            echo '<p>شما قبلاً وارد شده‌اید.</p>';
        } else {
            include LABASINO_SMS_PLUGIN_DIR . 'templates/login-form.php';
        }
        
        return ob_get_clean();
    }
}
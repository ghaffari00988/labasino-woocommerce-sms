/**
 * Labasino SMS Admin Scripts
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Admin scripts initialized
        console.log('Labasino SMS Admin loaded');
    });
    
})(jQuery);
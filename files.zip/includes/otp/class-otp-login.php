<?php
/**
 * OTP Login Class
 * Handles login with OTP
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_OTP_Login {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // AJAX handlers
        add_action('wp_ajax_nopriv_labasino_send_login_otp', array($this, 'ajax_send_otp'));
        add_action('wp_ajax_nopriv_labasino_verify_login_otp', array($this, 'ajax_verify_otp'));
        
        // Disable default login for users registered via OTP
        add_filter('authenticate', array($this, 'maybe_disable_password_login'), 30, 3);
    }
    
    /**
     * AJAX: Send login OTP
     */
    public function ajax_send_otp() {
        check_ajax_referer('labasino-sms-frontend', 'nonce');
        
        $mobile = isset($_POST['mobile']) ? sanitize_text_field($_POST['mobile']) : '';
        
        if (empty($mobile)) {
            wp_send_json_error(array(
                'message' => 'لطفاً شماره موبایل را وارد کنید'
            ));
        }
        
        // Check if user exists with this mobile
        $user = $this->get_user_by_mobile($mobile);
        
        if (!$user) {
            wp_send_json_error(array(
                'message' => 'کاربری با این شماره موبایل یافت نشد. ابتدا ثبت‌نام کنید.'
            ));
        }
        
        // Send OTP
        $otp_manager = Labasino_SMS_OTP_Manager::get_instance();
        $result = $otp_manager->create_and_send_otp($mobile);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'message' => $result['message'],
                'expires_in' => $result['expires_in']
            ));
        } else {
            wp_send_json_error(array(
                'message' => $result['message']
            ));
        }
    }
    
    /**
     * AJAX: Verify login OTP
     */
    public function ajax_verify_otp() {
        check_ajax_referer('labasino-sms-frontend', 'nonce');
        
        $mobile = isset($_POST['mobile']) ? sanitize_text_field($_POST['mobile']) : '';
        $code = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';
        
        if (empty($mobile) || empty($code)) {
            wp_send_json_error(array(
                'message' => 'لطفاً تمام فیلدها را پر کنید'
            ));
        }
        
        // Verify OTP
        $otp_manager = Labasino_SMS_OTP_Manager::get_instance();
        $result = $otp_manager->verify_otp($mobile, $code);
        
        if (!$result['success']) {
            wp_send_json_error(array(
                'message' => $result['message']
            ));
        }
        
        // Get user
        $user = $this->get_user_by_mobile($mobile);
        
        if (!$user) {
            wp_send_json_error(array(
                'message' => 'کاربر یافت نشد'
            ));
        }
        
        // Log user in
        wp_clear_auth_cookie();
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        
        // Update last login
        update_user_meta($user->ID, 'labasino_last_login', current_time('mysql'));
        
        Labasino_SMS_Logger::success('User logged in via OTP', array(
            'user_id' => $user->ID,
            'mobile' => $mobile
        ));
        
        do_action('labasino_sms_after_otp_login', $user->ID);
        
        // Get redirect URL
        $redirect_to = isset($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : wc_get_page_permalink('myaccount');
        
        wp_send_json_success(array(
            'message' => 'ورود موفقیت‌آمیز بود',
            'redirect_to' => $redirect_to,
            'user' => array(
                'id' => $user->ID,
                'display_name' => $user->display_name
            )
        ));
    }
    
    /**
     * Get user by mobile number
     */
    private function get_user_by_mobile($mobile) {
        $users = get_users(array(
            'meta_key' => 'billing_phone',
            'meta_value' => $mobile,
            'number' => 1
        ));
        
        return !empty($users) ? $users[0] : null;
    }
    
    /**
     * Maybe disable password login for OTP-only users
     */
    public function maybe_disable_password_login($user, $username, $password) {
        if (is_wp_error($user)) {
            return $user;
        }
        
        // Check if user is OTP-only
        if ($user instanceof WP_User) {
            $otp_only = get_user_meta($user->ID, 'labasino_otp_only', true);
            
            if ($otp_only === 'yes') {
                return new WP_Error(
                    'otp_only_user',
                    __('این حساب کاربری فقط از طریق کد یکبار مصرف قابل ورود است.', 'labasino-sms')
                );
            }
        }
        
        return $user;
    }
}
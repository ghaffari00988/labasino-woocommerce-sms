/**
 * Labasino SMS Frontend Scripts
 */

(function($) {
    'use strict';
    
    let currentMobile = '';
    let otpTimer = null;
    let timeLeft = 120;
    let isLoginFlow = true; // true = login, false = register
    
    $(document).ready(function() {
        initMobileForm();
        initOTPForm();
        initRegisterForm();
        initOTPInputs();
    });
    
    /**
     * Initialize mobile form
     */
    function initMobileForm() {
        $('#labasino-mobile-form').on('submit', function(e) {
            e.preventDefault();
            
            const mobile = $('#labasino-mobile').val().trim();
            
            if (!validateMobile(mobile)) {
                showNotice('mobile-notice', 'شماره موبایل نامعتبر است', 'error');
                return;
            }
            
            currentMobile = mobile;
            sendOTP(mobile);
        });
    }
    
    /**
     * Send OTP
     */
    function sendOTP(mobile) {
        const $btn = $('#send-otp-btn');
        const $btnText = $btn.find('.btn-text');
        const $btnLoading = $btn.find('.btn-loading');
        
        $.ajax({
            url: labasinoSMS.ajax_url,
            type: 'POST',
            data: {
                action: 'labasino_send_login_otp',
                nonce: labasinoSMS.nonce,
                mobile: mobile
            },
            beforeSend: function() {
                $btn.prop('disabled', true);
                $btnText.hide();
                $btnLoading.show();
                hideNotice('mobile-notice');
            },
            success: function(response) {
                if (response.success) {
                    isLoginFlow = true;
                    showOTPStep();
                    startOTPTimer(response.data.expires_in * 60);
                } else {
                    // Check if user doesn't exist
                    if (response.data.message && response.data.message.includes('یافت نشد')) {
                        // Try register flow
                        sendRegisterOTP(mobile);
                    } else {
                        showNotice('mobile-notice', response.data.message, 'error');
                    }
                }
            },
            error: function() {
                showNotice('mobile-notice', 'خطا در برقراری ارتباط با سرور', 'error');
            },
            complete: function() {
                $btn.prop('disabled', false);
                $btnText.show();
                $btnLoading.hide();
            }
        });
    }
    
    /**
     * Send register OTP
     */
    function sendRegisterOTP(mobile) {
        $.ajax({
            url: labasinoSMS.ajax_url,
            type: 'POST',
            data: {
                action: 'labasino_send_register_otp',
                nonce: labasinoSMS.nonce,
                mobile: mobile
            },
            success: function(response) {
                if (response.success) {
                    isLoginFlow = false;
                    showOTPStep();
                    startOTPTimer(response.data.expires_in * 60);
                } else {
                    showNotice('mobile-notice', response.data.message, 'error');
                }
            }
        });
    }
    
    /**
     * Show OTP step
     */
    function showOTPStep() {
        $('#step-mobile').fadeOut(200, function() {
            $('#step-otp').fadeIn(200);
            $('#display-mobile').text(maskMobile(currentMobile));
            $('.otp-input').first().focus();
        });
    }
    
    /**
     * Initialize OTP form
     */
    function initOTPForm() {
        $('#labasino-otp-form').on('submit', function(e) {
            e.preventDefault();
            
            const code = getOTPCode();
            
            if (code.length !== 6) {
                showNotice('otp-notice', 'لطفاً کد 6 رقمی را کامل وارد کنید', 'error');
                return;
            }
            
            verifyOTP(code);
        });
        
        // Back to mobile
        $('#back-to-mobile, #edit-mobile').on('click', function() {
            backToMobileStep();
        });
        
        // Resend OTP
        $('#resend-otp').on('click', function() {
            sendOTP(currentMobile);
        });
    }
    
    /**
     * Verify OTP
     */
    function verifyOTP(code) {
        const $btn = $('#verify-otp-btn');
        const $btnText = $btn.find('.btn-text');
        const $btnLoading = $btn.find('.btn-loading');
        const action = isLoginFlow ? 'labasino_verify_login_otp' : 'labasino_verify_register_otp';
        
        $.ajax({
            url: labasinoSMS.ajax_url,
            type: 'POST',
            data: {
                action: action,
                nonce: labasinoSMS.nonce,
                mobile: currentMobile,
                code: code,
                redirect_to: $('#redirect-to').val()
            },
            beforeSend: function() {
                $btn.prop('disabled', true);
                $btnText.hide();
                $btnLoading.show();
                hideNotice('otp-notice');
            },
            success: function(response) {
                if (response.success) {
                    if (isLoginFlow) {
                        // Login successful
                        showNotice('otp-notice', 'ورود موفقیت‌آمیز بود...', 'success');
                        setTimeout(function() {
                            window.location.href = response.data.redirect_to;
                        }, 1000);
                    } else {
                        // Show register step
                        showRegisterStep();
                    }
                } else {
                    showNotice('otp-notice', response.data.message, 'error');
                    clearOTPInputs();
                }
            },
            error: function() {
                showNotice('otp-notice', 'خطا در برقراری ارتباط با سرور', 'error');
            },
            complete: function() {
                $btn.prop('disabled', false);
                $btnText.show();
                $btnLoading.hide();
            }
        });
    }
    
    /**
     * Show register step
     */
    function showRegisterStep() {
        $('#step-otp').fadeOut(200, function() {
            $('#step-register').fadeIn(200);
            $('#first-name').focus();
        });
    }
    
    /**
     * Initialize register form
     */
    function initRegisterForm() {
        $('#labasino-register-form').on('submit', function(e) {
            e.preventDefault();
            
            const firstName = $('#first-name').val().trim();
            const lastName = $('#last-name').val().trim();
            const code = getOTPCode();
            
            if (!firstName || !lastName) {
                showNotice('register-notice', 'لطفاً تمام فیلدها را پر کنید', 'error');
                return;
            }
            
            completeRegistration(firstName, lastName, code);
        });
    }
    
    /**
     * Complete registration
     */
    function completeRegistration(firstName, lastName, code) {
        const $btn = $('#register-btn');
        const $btnText = $btn.find('.btn-text');
        const $btnLoading = $btn.find('.btn-loading');
        
        $.ajax({
            url: labasinoSMS.ajax_url,
            type: 'POST',
            data: {
                action: 'labasino_verify_register_otp',
                nonce: labasinoSMS.nonce,
                mobile: currentMobile,
                code: code,
                first_name: firstName,
                last_name: lastName,
                redirect_to: $('#redirect-to').val()
            },
            beforeSend: function() {
                $btn.prop('disabled', true);
                $btnText.hide();
                $btnLoading.show();
                hideNotice('register-notice');
            },
            success: function(response) {
                if (response.success) {
                    showNotice('register-notice', 'ثبت‌نام با موفقیت انجام شد...', 'success');
                    setTimeout(function() {
                        window.location.href = response.data.redirect_to;
                    }, 1000);
                } else {
                    showNotice('register-notice', response.data.message, 'error');
                }
            },
            error: function() {
                showNotice('register-notice', 'خطا در برقراری ارتباط با سرور', 'error');
            },
            complete: function() {
                $btn.prop('disabled', false);
                $btnText.show();
                $btnLoading.hide();
            }
        });
    }
    
    /**
     * Initialize OTP inputs
     */
    function initOTPInputs() {
        $('.otp-input').on('input', function() {
            const $this = $(this);
            const value = $this.val();
            
            // Only allow numbers
            if (!/^\d$/.test(value)) {
                $this.val('');
                return;
            }
            
            // Move to next input
            const $next = $this.next('.otp-input');
            if ($next.length) {
                $next.focus();
            } else {
                // All filled, auto-submit
                $('#labasino-otp-form').submit();
            }
        });
        
        $('.otp-input').on('keydown', function(e) {
            const $this = $(this);
            
            // Backspace
            if (e.keyCode === 8 && !$this.val()) {
                const $prev = $this.prev('.otp-input');
                if ($prev.length) {
                    $prev.focus().val('');
                }
            }
        });
        
        // Paste handling
        $('.otp-input').first().on('paste', function(e) {
            e.preventDefault();
            const pastedData = (e.originalEvent || e).clipboardData.getData('text/plain');
            const digits = pastedData.replace(/\D/g, '').substr(0, 6);
            
            $('.otp-input').each(function(index) {
                if (digits[index]) {
                    $(this).val(digits[index]);
                }
            });
            
            if (digits.length === 6) {
                $('#labasino-otp-form').submit();
            }
        });
    }
    
    /**
     * Start OTP timer
     */
    function startOTPTimer(seconds) {
        timeLeft = seconds;
        updateTimerDisplay();
        
        $('#otp-timer-text').show();
        $('#resend-otp').hide();
        
        if (otpTimer) {
            clearInterval(otpTimer);
        }
        
        otpTimer = setInterval(function() {
            timeLeft--;
            updateTimerDisplay();
            
            if (timeLeft <= 0) {
                clearInterval(otpTimer);
                $('#otp-timer-text').hide();
                $('#resend-otp').show();
            }
        }, 1000);
    }
    
    /**
     * Update timer display
     */
    function updateTimerDisplay() {
        $('#timer-count').text(timeLeft);
    }
    
    /**
     * Get OTP code from inputs
     */
    function getOTPCode() {
        let code = '';
        $('.otp-input').each(function() {
            code += $(this).val();
        });
        return code;
    }
    
    /**
     * Clear OTP inputs
     */
    function clearOTPInputs() {
        $('.otp-input').val('');
        $('.otp-input').first().focus();
    }
    
    /**
     * Back to mobile step
     */
    function backToMobileStep() {
        if (otpTimer) {
            clearInterval(otpTimer);
        }
        
        clearOTPInputs();
        hideNotice('otp-notice');
        
        $('#step-otp, #step-register').fadeOut(200, function() {
            $('#step-mobile').fadeIn(200);
            $('#labasino-mobile').focus();
        });
    }
    
    /**
     * Validate mobile number
     */
    function validateMobile(mobile) {
        return /^09\d{9}$/.test(mobile);
    }
    
    /**
     * Mask mobile number
     */
    function maskMobile(mobile) {
        if (mobile.length === 11) {
            return mobile.substr(0, 4) + '***' + mobile.substr(-4);
        }
        return mobile;
    }
    
    /**
     * Show notice
     */
    function showNotice(elementId, message, type) {
        const $notice = $('#' + elementId);
        $notice.removeClass('notice-error notice-success notice-info');
        $notice.addClass('notice-' + type);
        $notice.text(message);
        $notice.slideDown(200);
    }
    
    /**
     * Hide notice
     */
    function hideNotice(elementId) {
        $('#' + elementId).slideUp(200);
    }
    
})(jQuery);
<?php
/**
 * Logger Class
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_Logger {
    
    /**
     * Log levels
     */
    const LEVEL_INFO = 'info';
    const LEVEL_WARNING = 'warning';
    const LEVEL_ERROR = 'error';
    const LEVEL_SUCCESS = 'success';
    
    /**
     * Write log
     * 
     * @param string $message Log message
     * @param string $level Log level
     * @param array $context Additional context
     */
    public static function log($message, $level = self::LEVEL_INFO, $context = array()) {
        $log_enabled = get_option('labasino_sms_enable_logging', 'yes');
        
        if ($log_enabled !== 'yes') {
            return;
        }
        
        $log_file = LABASINO_SMS_PLUGIN_DIR . 'logs/labasino-sms.log';
        $log_dir = dirname($log_file);
        
        // Create logs directory if not exists
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }
        
        $timestamp = current_time('Y-m-d H:i:s');
        $context_str = !empty($context) ? ' | Context: ' . json_encode($context) : '';
        
        $log_entry = sprintf(
            "[%s] [%s] %s%s\n",
            $timestamp,
            strtoupper($level),
            $message,
            $context_str
        );
        
        error_log($log_entry, 3, $log_file);
    }
    
    /**
     * Log info
     */
    public static function info($message, $context = array()) {
        self::log($message, self::LEVEL_INFO, $context);
    }
    
    /**
     * Log warning
     */
    public static function warning($message, $context = array()) {
        self::log($message, self::LEVEL_WARNING, $context);
    }
    
    /**
     * Log error
     */
    public static function error($message, $context = array()) {
        self::log($message, self::LEVEL_ERROR, $context);
    }
    
    /**
     * Log success
     */
    public static function success($message, $context = array()) {
        self::log($message, self::LEVEL_SUCCESS, $context);
    }
}
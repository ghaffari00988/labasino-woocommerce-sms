<?php
/**
 * OTP Manager Class
 * Manages OTP generation, validation, and storage
 * 
 * @package Labasino_SMS
 */

if (!defined('ABSPATH')) {
    exit;
}

class Labasino_SMS_OTP_Manager {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Clean expired OTPs daily
        add_action('labasino_sms_cleanup_expired_otps', array($this, 'cleanup_expired_otps'));
        
        if (!wp_next_scheduled('labasino_sms_cleanup_expired_otps')) {
            wp_schedule_event(time(), 'daily', 'labasino_sms_cleanup_expired_otps');
        }
    }
    
    /**
     * Generate OTP code
     * 
     * @param int $length OTP length
     * @return string
     */
    public function generate_code($length = null) {
        if (null === $length) {
            $length = intval(get_option('labasino_sms_otp_length', 6));
        }
        
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= mt_rand(0, 9);
        }
        
        return $code;
    }
    
    /**
     * Create and send OTP
     * 
     * @param string $mobile Mobile number
     * @return array Result array
     */
    public function create_and_send_otp($mobile) {
        global $wpdb;
        
        // Validate mobile
        $mobile = $this->validate_mobile($mobile);
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        // Check rate limiting
        $can_send = $this->check_rate_limit($mobile);
        if (!$can_send['success']) {
            return $can_send;
        }
        
        // Generate code
        $code = $this->generate_code();
        
        // Calculate expiry time
        $expiry_minutes = intval(get_option('labasino_sms_otp_expiry', 2));
        $expires_at = date('Y-m-d H:i:s', strtotime('+' . $expiry_minutes . ' minutes'));
        
        // Get client IP
        $ip_address = $this->get_client_ip();
        
        // Store OTP in database
        $table = $wpdb->prefix . 'labasino_sms_otp';
        $result = $wpdb->insert(
            $table,
            array(
                'mobile' => $mobile,
                'code' => $code,
                'created_at' => current_time('mysql'),
                'expires_at' => $expires_at,
                'verified' => 0,
                'attempts' => 0,
                'ip_address' => $ip_address
            ),
            array('%s', '%s', '%s', '%s', '%d', '%d', '%s')
        );
        
        if (!$result) {
            Labasino_SMS_Logger::error('Failed to store OTP in database', array(
                'mobile' => $mobile,
                'error' => $wpdb->last_error
            ));
            
            return array(
                'success' => false,
                'message' => 'خطا در ذخیره کد تایید'
            );
        }
        
        // Send OTP via SMS
        $gateway = Labasino_SMS_Gateway_Manager::get_instance();
        $send_result = $gateway->send_otp($mobile, $code);
        
        if ($send_result['success']) {
            Labasino_SMS_Logger::success('OTP sent successfully', array(
                'mobile' => $mobile,
                'code' => $code
            ));
            
            return array(
                'success' => true,
                'message' => sprintf('کد تایید به شماره %s ارسال شد', $this->mask_mobile($mobile)),
                'expires_in' => $expiry_minutes
            );
        } else {
            Labasino_SMS_Logger::error('Failed to send OTP', array(
                'mobile' => $mobile,
                'error' => $send_result['message']
            ));
            
            return array(
                'success' => false,
                'message' => 'خطا در ارسال کد تایید: ' . $send_result['message']
            );
        }
    }
    
    /**
     * Verify OTP
     * 
     * @param string $mobile Mobile number
     * @param string $code OTP code
     * @return array Result array
     */
    public function verify_otp($mobile, $code) {
        global $wpdb;
        
        $mobile = $this->validate_mobile($mobile);
        if (!$mobile) {
            return array(
                'success' => false,
                'message' => 'شماره موبایل نامعتبر است'
            );
        }
        
        $table = $wpdb->prefix . 'labasino_sms_otp';
        
        // Get latest OTP for this mobile
        $otp = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table 
            WHERE mobile = %s 
            AND verified = 0 
            ORDER BY created_at DESC 
            LIMIT 1",
            $mobile
        ));
        
        if (!$otp) {
            return array(
                'success' => false,
                'message' => 'کد تایید یافت نشد'
            );
        }
        
        // Check if expired
        if (strtotime($otp->expires_at) < current_time('timestamp')) {
            return array(
                'success' => false,
                'message' => 'کد تایید منقضی شده است'
            );
        }
        
        // Increment attempts
        $wpdb->update(
            $table,
            array('attempts' => $otp->attempts + 1),
            array('id' => $otp->id),
            array('%d'),
            array('%d')
        );
        
        // Check max attempts
        $max_attempts = 5;
        if ($otp->attempts >= $max_attempts) {
            return array(
                'success' => false,
                'message' => 'تعداد تلاش‌های مجاز تمام شده است'
            );
        }
        
        // Verify code
        if ($otp->code !== $code) {
            return array(
                'success' => false,
                'message' => sprintf('کد تایید اشتباه است (%d تلاش باقیمانده)', $max_attempts - $otp->attempts - 1)
            );
        }
        
        // Mark as verified
        $wpdb->update(
            $table,
            array('verified' => 1),
            array('id' => $otp->id),
            array('%d'),
            array('%d')
        );
        
        Labasino_SMS_Logger::success('OTP verified successfully', array(
            'mobile' => $mobile
        ));
        
        return array(
            'success' => true,
            'message' => 'کد تایید با موفقیت تأیید شد',
            'mobile' => $mobile
        );
    }
    
    /**
     * Check rate limiting
     * 
     * @param string $mobile Mobile number
     * @return array
     */
    private function check_rate_limit($mobile) {
        global $wpdb;
        
        $limit = intval(get_option('labasino_sms_otp_limit', 3));
        $limit_time = intval(get_option('labasino_sms_otp_limit_time', 10));
        
        $table = $wpdb->prefix . 'labasino_sms_otp';
        $time_threshold = date('Y-m-d H:i:s', strtotime('-' . $limit_time . ' minutes'));
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table 
            WHERE mobile = %s 
            AND created_at >= %s",
            $mobile,
            $time_threshold
        ));
        
        if ($count >= $limit) {
            return array(
                'success' => false,
                'message' => sprintf('حداکثر %d درخواست در %d دقیقه مجاز است. لطفاً بعداً تلاش کنید.', $limit, $limit_time)
            );
        }
        
        return array('success' => true);
    }
    
    /**
     * Validate mobile number
     */
    private function validate_mobile($mobile) {
        $mobile = preg_replace('/[^0-9+]/', '', $mobile);
        
        if (preg_match('/^(\+98|0098|98|0)9\d{9}$/', $mobile)) {
            $mobile = preg_replace('/^(\+98|0098|98)/', '0', $mobile);
            return $mobile;
        }
        
        return false;
    }
    
    /**
     * Mask mobile number for display
     */
    private function mask_mobile($mobile) {
        if (strlen($mobile) === 11) {
            return substr($mobile, 0, 4) . '***' . substr($mobile, -4);
        }
        return $mobile;
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    }
    
    /**
     * Cleanup expired OTPs
     */
    public function cleanup_expired_otps() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'labasino_sms_otp';
        
        // Delete OTPs older than 24 hours
        $deleted = $wpdb->query(
            "DELETE FROM $table 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        );
        
        if ($deleted) {
            Labasino_SMS_Logger::info('Cleaned up expired OTPs', array('count' => $deleted));
        }
    }
}